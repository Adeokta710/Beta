
# Technology Study Surabaya

**Ayo Arek Arek Suroboyo, Belajar Teknologi mulai Saiki**  
**Gen Z Cerdas, Surabaya Hebat**

Website pusat pembelajaran teknologi dengan 3 pilar:

1. Coding
2. Elektronika
3. Hardware & Software

Setiap pilar memiliki:
- Materi — penjelasan detail
- Tutorial — praktik dari awal sampai selesai
- Problem Solved — analisa → pemeriksaan → diagnosis → perbaikan/penggantian → uji coba

## Struktur

```text
Technology Study Surabaya
├── Coding
│   ├── Materi
│   ├── Tutorial
│   └── Problem Solved
├── Elektronika
│   ├── Materi
│   ├── Tutorial
│   └── Problem Solved
└── Hardware & Software
    ├── Materi
    ├── Tutorial
    └── Problem Solved
```

Database sudah dipisahkan untuk:
- User
- Category
- Article
- Brand
- ProductModel
- Component
- Bookmark
- Progress

Sistem artikel tidak lagi ditulis dengan `if slug == ...` di HTML. Konten berasal dari database sehingga bisa dikembangkan menjadi ribuan/puluhan ribu konten.

## Jalankan

```bash
python -m venv venv
# Windows
venv\Scripts\activate
# Linux/Termux
source venv/bin/activate

pip install -r requirements.txt
python app.py
```

Buka:
`http://127.0.0.1:5000`

Database SQLite `tss.db` akan dibuat otomatis saat aplikasi pertama dijalankan.

## Catatan konten

Data contoh hanyalah seed awal. Website belum mengklaim database komponen atau semua model perangkat sudah lengkap. Konten produksi harus ditambahkan setelah diverifikasi dari sumber resmi/datasheet/manual dan sumber teknis terpercaya.
