
from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from sqlalchemy import or_
import os, json

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("TSS_SECRET_KEY", "change-this-secret-in-production")

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "tss.db")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + DB_PATH
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

# =========================
# DATABASE MODELS
# =========================

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(120), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    bookmarks = db.relationship("Bookmark", backref="user", lazy=True, cascade="all, delete-orphan")
    progress = db.relationship("Progress", backref="user", lazy=True, cascade="all, delete-orphan")

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    slug = db.Column(db.String(80), unique=True, nullable=False)
    icon = db.Column(db.String(20), default="📚")
    description = db.Column(db.Text, default="")
    articles = db.relationship("Article", backref="category", lazy=True)

class Article(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(220), nullable=False)
    slug = db.Column(db.String(220), unique=True, nullable=False)
    content_type = db.Column(db.String(30), nullable=False)  # materi/tutorial/problem
    content = db.Column(db.Text, nullable=False)
    summary = db.Column(db.Text, default="")
    category_id = db.Column(db.Integer, db.ForeignKey("category.id"), nullable=False)
    level = db.Column(db.String(20), default="pemula")
    tags = db.Column(db.String(500), default="")
    author = db.Column(db.String(100), default="Adeokta")
    references = db.Column(db.Text, default="[]")  # JSON list
    image_url = db.Column(db.String(500), default="")
    related_ids = db.Column(db.String(500), default="")
    views = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Brand(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False)
    slug = db.Column(db.String(120), unique=True, nullable=False)
    device_type = db.Column(db.String(40), default="smartphone")  # smartphone/laptop/pc/component

class ProductModel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    brand_id = db.Column(db.Integer, db.ForeignKey("brand.id"), nullable=False)
    name = db.Column(db.String(180), nullable=False)
    slug = db.Column(db.String(180), nullable=False)
    device_type = db.Column(db.String(40), default="smartphone")
    year = db.Column(db.Integer)
    specs = db.Column(db.Text, default="{}")
    brand = db.relationship("Brand", backref=db.backref("models", lazy=True))

class Component(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(180), nullable=False)
    part_number = db.Column(db.String(120), default="")
    component_type = db.Column(db.String(80), default="")
    subtype = db.Column(db.String(100), default="")
    package = db.Column(db.String(80), default="")
    specs = db.Column(db.Text, default="{}")
    datasheet_url = db.Column(db.String(500), default="")
    description = db.Column(db.Text, default="")

class Bookmark(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    article_id = db.Column(db.Integer, db.ForeignKey("article.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    article = db.relationship("Article")

class Progress(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    article_id = db.Column(db.Integer, db.ForeignKey("article.id"), nullable=False)
    status = db.Column(db.String(20), default="started")
    last_read = db.Column(db.DateTime, default=datetime.utcnow)
    article = db.relationship("Article")

# =========================
# CONTENT / STRUCTURE
# =========================

CATEGORIES = {
    "coding": ("💻", "Coding", "Pemrograman dari dasar sampai tingkat lanjut, praktik project, debugging, server, database, dan problem solving."),
    "elektronika": ("⚡", "Elektronika", "Ilmu komponen, rangkaian, pengukuran, perakitan, troubleshooting, datasheet, dan praktik elektronika."),
    "hardware-software": ("📱", "Hardware & Software", "Smartphone, laptop, PC, hardware, operating system, firmware, diagnosis, perbaikan, dan pengujian.")
}
CONTENT_TYPES = {
    "materi": ("📚", "Materi", "Penjelasan informasi dan konsep secara detail."),
    "tutorial": ("🛠️", "Tutorial", "Praktik langkah demi langkah dari awal sampai selesai."),
    "problem": ("🔧", "Problem Solved", "Analisa gejala, pemeriksaan, diagnosis, perbaikan, penggantian, dan uji coba.")
}

def seed():
    db.create_all()

    for slug, (icon, name, desc) in CATEGORIES.items():
        if not Category.query.filter_by(slug=slug).first():
            db.session.add(Category(name=name, slug=slug, icon=icon, description=desc))
    db.session.commit()

    samples = [
        ("coding","materi","Dasar Pemrograman","dasar-pemrograman","Memahami variabel, tipe data, operator, percabangan, perulangan, fungsi, struktur data, dan cara berpikir algoritmik.","pemula","dasar,programming,algoritma"),
        ("coding","materi","HTML Dasar","html-dasar","Struktur halaman HTML, semantic HTML, elemen, atribut, form, link, gambar, dan praktik dasar.","pemula","html,web"),
        ("coding","tutorial","Membuat Website Pertama dengan HTML & CSS","website-html-css","Praktik dari file kosong sampai halaman website responsif selesai.","pemula","html,css,website,project"),
        ("coding","problem","ModuleNotFoundError pada Python","python-module-not-found","Analisa penyebab import module gagal, pengecekan environment, instalasi package, dan pengujian ulang.","pemula","python,error,debugging"),
        ("elektronika","materi","Resistor: Fungsi, Jenis, Kode, dan Pengukuran","resistor-lengkap","Membahas resistor tetap, variabel, potensiometer, trimpot, LDR, NTC, PTC, nilai, kode warna, toleransi, daya, fungsi, dan cara mengukur.","pemula","resistor,komponen,multimeter"),
        ("elektronika","materi","Transistor: BJT, MOSFET, JFET, IGBT dan Jenisnya","transistor-lengkap","Pengenalan keluarga transistor, karakteristik, package, pinout, penggunaan, pengujian, dan cara membaca datasheet.","menengah","transistor,bjt,mosfet,jfet,igbt"),
        ("elektronika","tutorial","Cara Mengukur Resistor dengan Multimeter","ukur-resistor","Praktik memilih mode ukur, memasang probe, membaca hasil, membandingkan dengan nilai nominal, dan menentukan kondisi komponen.","pemula","resistor,multimeter,pengukuran"),
        ("elektronika","tutorial","Cara Menguji Transistor BJT dengan Multimeter","uji-transistor-bjt","Langkah identifikasi kaki dan pemeriksaan junction menggunakan multimeter.","pemula","transistor,bjt,multimeter"),
        ("elektronika","problem","Power Supply Mati karena MOSFET Short","psu-mosfet-short","Contoh alur diagnosis dari gejala, pemeriksaan short, pengukuran, pencarian penyebab, penggantian part, dan pengujian.","lanjutan","power-supply,mosfet,troubleshooting"),
        ("hardware-software","materi","Samsung Galaxy A54: Hardware & Software","samsung-a54","Ringkasan spesifikasi, komponen utama, sistem operasi, konektivitas, charging, display, sensor, dan informasi servis yang tersedia.","pemula","samsung,a54,smartphone"),
        ("hardware-software","tutorial","Cara Diagnosis Smartphone Tidak Bisa Charging","diagnosis-smartphone-charging","Alur pemeriksaan dari charger, kabel, port, konektor, konsumsi arus, software, hingga pemeriksaan board secara aman.","menengah","smartphone,charging,diagnosis"),
        ("hardware-software","problem","Samsung Galaxy A54 Tidak Bisa Charging","a54-tidak-bisa-charging","Contoh kasus problem solving: gejala, identifikasi, pemeriksaan port dan jalur, diagnosis, kemungkinan penggantian part, dan uji coba.","menengah","samsung,a54,charging,problem-solved"),
    ]

    existing = {a.slug for a in Article.query.all()}
    for cat_slug, ctype, title, slug, summary, level, tags in samples:
        if slug in existing:
            continue
        cat = Category.query.filter_by(slug=cat_slug).first()
        content = article_template(ctype, title, summary, cat.name)
        db.session.add(Article(
            title=title, slug=slug, content_type=ctype, content=content,
            summary=summary, category_id=cat.id, level=level, tags=tags,
            references=json.dumps([], ensure_ascii=False)
        ))

    # Basic technology databases: expandable, not a claim of exhaustive coverage.
    brands = [
        ("Samsung","samsung","smartphone"),("Xiaomi","xiaomi","smartphone"),
        ("Redmi","redmi","smartphone"),("POCO","poco","smartphone"),
        ("OPPO","oppo","smartphone"),("vivo","vivo","smartphone"),
        ("realme","realme","smartphone"),("Infinix","infinix","smartphone"),
        ("TECNO","tecno","smartphone"),("ASUS","asus","laptop"),
        ("Acer","acer","laptop"),("Lenovo","lenovo","laptop"),
        ("HP","hp","laptop"),("Dell","dell","laptop"),("MSI","msi","laptop"),
        ("Apple","apple","smartphone"),("Toshiba","toshiba","laptop")
    ]
    for name, slug, dtype in brands:
        if not Brand.query.filter_by(slug=slug).first():
            db.session.add(Brand(name=name, slug=slug, device_type=dtype))

    component_rows = [
        ("Resistor","resistor","fixed",""),("Potensiometer","resistor","variable",""),
        ("Trimpot","resistor","variable",""),("LDR","resistor","sensor",""),
        ("NTC","resistor","thermistor",""),("PTC","resistor","thermistor",""),
        ("Capacitor Ceramic","capacitor","ceramic",""),("Electrolytic Capacitor","capacitor","electrolytic",""),
        ("Film Capacitor","capacitor","film",""),("Tantalum Capacitor","capacitor","tantalum",""),
        ("Rectifier Diode","diode","rectifier",""),("Zener Diode","diode","zener",""),
        ("Schottky Diode","diode","schottky",""),("LED","diode","led",""),
        ("TVS Diode","diode","tvs",""),("NPN Transistor","transistor","bjt",""),
        ("PNP Transistor","transistor","bjt",""),("N-Channel MOSFET","transistor","mosfet",""),
        ("P-Channel MOSFET","transistor","mosfet",""),("JFET","transistor","jfet",""),
        ("IGBT","transistor","igbt",""),("Op-Amp IC","ic","op-amp",""),
        ("Timer IC","ic","timer",""),("Voltage Regulator IC","ic","regulator",""),
        ("Audio Amplifier IC","ic","audio",""),("Relay","other","relay",""),
        ("Fuse","other","fuse",""),("Transformer","other","transformer",""),
        ("Inductor","other","inductor",""),("Crystal","other","oscillator",""),
        ("Sensor","other","sensor",""),("Speaker","other","audio","")
    ]
    existing_components = {(c.name, c.component_type, c.subtype) for c in Component.query.all()}
    for name, typ, sub, pkg in component_rows:
        if (name, typ, sub) not in existing_components:
            db.session.add(Component(name=name, component_type=typ, subtype=sub, package=pkg,
                                     description=f"Data awal kategori {name}. Lengkapi dengan datasheet dan sumber terpercaya sebelum dipublikasikan sebagai fakta spesifik."))

    db.session.commit()

def article_template(ctype, title, summary, category):
    if ctype == "materi":
        return f"""<h2>Ringkasan</h2><p>{summary}</p>
<h2>Apa itu?</h2><p>Jelaskan definisi {title} secara akurat dan mudah dipahami.</p>
<h2>Fungsi dan cara kerja</h2><p>Jelaskan fungsi, prinsip kerja, bagian penting, serta hubungan dengan teknologi terkait.</p>
<h2>Jenis dan perbedaan</h2><p>Kelompokkan jenis berdasarkan karakteristik yang benar. Gunakan tabel bila membantu.</p>
<h2>Spesifikasi dan karakteristik</h2><p>Masukkan spesifikasi hanya jika sudah diverifikasi dari sumber yang dapat dipercaya.</p>
<h2>Contoh penggunaan</h2><p>Berikan contoh nyata dan jelaskan alasan penggunaannya.</p>
<h2>Kesalahan umum</h2><p>Jelaskan kesalahan yang sering dilakukan pemula.</p>
<h2>Referensi</h2><p>Tambahkan sumber resmi/datasheet ketika konten final diterbitkan.</p>"""
    if ctype == "tutorial":
        return f"""<h2>Tujuan</h2><p>{summary}</p>
<h2>Alat dan bahan</h2><ul><li>Daftar alat yang diperlukan.</li><li>Komponen/perangkat yang diperlukan.</li></ul>
<h2>Persiapan</h2><p>Pastikan perangkat, alat, dan kondisi kerja aman.</p>
<h2>Langkah praktik</h2><ol><li>Langkah awal.</li><li>Langkah berikutnya.</li><li>Lakukan pemeriksaan hasil pada setiap tahap.</li></ol>
<h2>Pengujian</h2><p>Jelaskan hasil yang seharusnya dan cara memverifikasinya.</p>
<h2>Kesalahan yang mungkin terjadi</h2><p>Jelaskan gejala dan solusi.</p>
<h2>Keselamatan</h2><p>Berikan peringatan yang sesuai dengan risiko pekerjaan.</p>
<h2>Referensi</h2><p>Tambahkan sumber terpercaya.</p>"""
    return f"""<h2>1. Masalah</h2><p>{summary}</p>
<h2>2. Identifikasi</h2><p>Tentukan perangkat, model, komponen, versi software, atau kondisi yang terlibat.</p>
<h2>3. Analisa</h2><p>Buat beberapa kemungkinan penyebab dan bedakan fakta dari dugaan.</p>
<h2>4. Pemeriksaan</h2><p>Susun pemeriksaan dari yang paling aman dan sederhana ke pemeriksaan lanjutan.</p>
<h2>5. Pengukuran</h2><p>Jika diperlukan, gunakan tegangan, resistansi, kontinuitas, arus, temperatur, sinyal, log, atau pemeriksaan software.</p>
<h2>6. Diagnosis</h2><p>Tarik kesimpulan berdasarkan hasil pemeriksaan, bukan tebakan.</p>
<h2>7. Solusi</h2><p>Jelaskan perbaikan, penggantian, konfigurasi, reset, reinstall, atau tindakan lain yang relevan.</p>
<h2>8. Penggantian</h2><p>Jika part diganti, verifikasi part asli, kompatibilitas, perbedaan, dan risikonya.</p>
<h2>9. Uji coba</h2><p>Uji fungsi setelah perbaikan.</p>
<h2>10. Hasil akhir</h2><p>Catat hasil dan kondisi setelah perbaikan.</p>
<h2>11. Pencegahan</h2><p>Jelaskan cara mengurangi kemungkinan masalah terulang.</p>"""

@app.context_processor
def inject_globals():
    return {
        "categories": [Category.query.order_by(Category.id).all()],
        "content_types": CONTENT_TYPES,
        "current_user": session.get("user")
    }

@app.route("/")
def home():
    latest = Article.query.order_by(Article.updated_at.desc()).limit(6).all()
    return render_template("index.html", latest=latest)

@app.route("/<category_slug>")
def category(category_slug):
    if category_slug not in CATEGORIES:
        abort(404)
    cat = Category.query.filter_by(slug=category_slug).first_or_404()
    counts = {k: Article.query.filter_by(category_id=cat.id, content_type=k).count() for k in CONTENT_TYPES}
    return render_template("category.html", category=cat, counts=counts)

@app.route("/<category_slug>/<content_type>")
def content_list(category_slug, content_type):
    if category_slug not in CATEGORIES or content_type not in CONTENT_TYPES:
        abort(404)
    cat = Category.query.filter_by(slug=category_slug).first_or_404()
    page = max(request.args.get("page", 1, type=int), 1)
    per_page = 12
    pagination = Article.query.filter_by(category_id=cat.id, content_type=content_type).order_by(Article.updated_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    icon, label, _ = CONTENT_TYPES[content_type]
    return render_template("list.html", category=cat, content_type=content_type, title=label, icon=icon, items=pagination.items, pagination=pagination)

@app.route("/article/<slug>")
def article(slug):
    item = Article.query.filter_by(slug=slug).first_or_404()
    item.views = (item.views or 0) + 1
    db.session.commit()
    refs = json.loads(item.references or "[]")
    related = []
    if item.related_ids:
        ids = [int(x) for x in item.related_ids.split(",") if x.strip().isdigit()]
        if ids:
            related = Article.query.filter(Article.id.in_(ids)).all()
    if not related:
        related = Article.query.filter(
            Article.category_id == item.category_id,
            Article.id != item.id,
            Article.content_type == item.content_type
        ).limit(4).all()
    return render_template("article.html", item=item, references=refs, related=related)

@app.route("/search")
def search():
    q = request.args.get("q", "").strip()
    kategori = request.args.get("kategori", "").strip()
    jenis = request.args.get("jenis", "").strip()
    brand = request.args.get("brand", "").strip()
    model = request.args.get("model", "").strip()
    results = []
    if q:
        query = Article.query
        if kategori:
            cat = Category.query.filter_by(slug=kategori).first()
            if cat:
                query = query.filter_by(category_id=cat.id)
        if jenis:
            query = query.filter_by(content_type=jenis)
        like = f"%{q}%"
        query = query.filter(or_(Article.title.ilike(like), Article.summary.ilike(like), Article.content.ilike(like), Article.tags.ilike(like)))
        results = query.order_by(Article.views.desc(), Article.updated_at.desc()).limit(50).all()
    brands = Brand.query.order_by(Brand.name).all()
    return render_template("search.html", query=q, results=results, kategori=kategori, jenis=jenis, brand=brand, model=model, brands=brands)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            session["user_id"] = user.id
            session["user"] = user.username
            flash("Berhasil masuk.", "success")
            return redirect(url_for("home"))
        flash("Username atau password salah.", "error")
    return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        email = request.form.get("email","").strip()
        password = request.form.get("password","")
        if not username or not email or not password:
            flash("Semua kolom wajib diisi.", "error")
        elif User.query.filter(or_(User.username == username, User.email == email)).first():
            flash("Username atau email sudah digunakan.", "error")
        else:
            user = User(username=username, email=email, password_hash=generate_password_hash(password))
            db.session.add(user); db.session.commit()
            flash("Akun berhasil dibuat. Silakan login.", "success")
            return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("Berhasil keluar.", "success")
    return redirect(url_for("home"))

@app.route("/profile")
def profile():
    if "user_id" not in session:
        return redirect(url_for("login"))
    user = db.session.get(User, session["user_id"])
    if not user:
        session.clear()
        return redirect(url_for("login"))
    return render_template("profile.html", user=user)

@app.route("/bookmark/<int:article_id>", methods=["POST"])
def bookmark(article_id):
    if "user_id" not in session:
        return redirect(url_for("login"))
    exists = Bookmark.query.filter_by(user_id=session["user_id"], article_id=article_id).first()
    if exists:
        db.session.delete(exists)
        flash("Bookmark dihapus.", "success")
    else:
        db.session.add(Bookmark(user_id=session["user_id"], article_id=article_id))
        flash("Artikel disimpan.", "success")
    db.session.commit()
    return redirect(request.referrer or url_for("article", slug=Article.query.get_or_404(article_id).slug))

@app.cli.command("init-db")
def init_db_command():
    seed()
    print("Database initialized.")

with app.app_context():
    seed()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
