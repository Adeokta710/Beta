
document.addEventListener("DOMContentLoaded", () => {
  const menu = document.getElementById("sideMenu");
  const overlay = document.getElementById("overlay");
  const open = () => { menu.classList.add("open"); overlay.classList.add("open"); document.body.style.overflow="hidden"; };
  const close = () => { menu.classList.remove("open"); overlay.classList.remove("open"); document.body.style.overflow=""; };
  document.getElementById("menuToggle")?.addEventListener("click", open);
  document.getElementById("menuClose")?.addEventListener("click", close);
  overlay?.addEventListener("click", close);
  document.querySelectorAll(".nav-parent").forEach(btn => {
    btn.addEventListener("click", () => {
      const target = document.getElementById(btn.dataset.target);
      document.querySelectorAll(".nav-child").forEach(x => { if (x !== target) x.classList.remove("open"); });
      target.classList.toggle("open");
    });
  });
});
