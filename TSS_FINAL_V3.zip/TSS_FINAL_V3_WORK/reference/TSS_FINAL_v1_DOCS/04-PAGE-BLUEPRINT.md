# Page Blueprints

## Home
Header → Hero → Global Search → Main Categories → Learning Paths → Latest Materials → Latest Tutorials → Latest Problems → Tools → Popular Materials → CTA → Footer.

## Material list
Filters: category, level, status, duration, sort. Card: title, category, level, excerpt, duration, progress, bookmark.

## Material detail
Breadcrumb → title/meta → TOC → content → diagrams/examples/practice → related problems → related materials → bookmark → mark complete → prev/next.

## Tutorial detail
Goal → tools/materials → preparation → steps → test → result → troubleshooting → conclusion.

## Problem Solved
Problem → symptoms → possible causes → checks → measurements → analysis → solution → prevention.

## Tools
Categorized tools with deterministic calculations and validation. Client-side calculation is fine for non-sensitive deterministic tools; server-side only when persistence/authorization is required.

## Profile
Identity, progress summary, completed content, bookmarks, history, settings.

## Admin
Dashboard, content, categories, tools, shop, users, subscriptions, comments, settings, website/SEO/menu, audit logs.
