# Admin/CMS Blueprint

## Content workflow
Draft → Review → Publish → Archive

## Content editor fields
Title, slug, excerpt, category, tags, level, duration, hero image, body blocks, SEO title/description, canonical URL, status, author, reviewer, publishedAt.

## Safety
- Autosave draft
- Preview before publish
- Revision/version history
- Publish permission
- Audit log
- Optimistic concurrency/version check
- Media validation
