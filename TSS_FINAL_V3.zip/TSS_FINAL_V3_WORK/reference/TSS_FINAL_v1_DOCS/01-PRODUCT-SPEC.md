# TSS Product Specification

## Positioning
Platform belajar teknologi dari dasar sampai praktik: coding, elektronika, hardware/software, troubleshooting, dan tools.

## User personas
- Pelajar/siswa SMK
- Mahasiswa
- Programmer
- Teknisi
- Pembelajar umum

## Core journeys
1. Pengunjung → cari materi → baca → daftar → tandai progress.
2. User → pilih learning path → belajar bertahap → bookmark → selesai.
3. User → mencari masalah → membaca diagnosis → mengikuti solusi.
4. Admin/instructor → draft → review → publish → monitor engagement.

## Content types
- Material
- Tutorial
- Problem Solved
- Quiz (opsional tetapi disiapkan model)
- Tool

## Status content
DRAFT → IN_REVIEW → PUBLISHED → ARCHIVED

## Level
BEGINNER / INTERMEDIATE / ADVANCED
