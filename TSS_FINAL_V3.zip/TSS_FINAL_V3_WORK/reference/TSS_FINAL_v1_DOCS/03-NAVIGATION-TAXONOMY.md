# Navigation & Taxonomy

## Rule
Navigation = what users use to move.
Taxonomy = how knowledge is organized.
Content = actual learning objects.

Do not hard-code the entire taxonomy into the sidebar.

## Primary taxonomy
### Coding & Programming
HTML, CSS, JavaScript, Python, C, C++, Java, Kotlin, PHP, SQL, Dart, Go, Rust.

### Elektronika
Dasar Elektronika, Hukum Dasar, Alat Ukur, Komponen, Audio, Power Supply, Mikrokontroler.

### Hardware & Software
Computer, Smartphone, Networking, Software.

## Deep examples
Coding/JavaScript → Fundamental → Variable, Data Type, Function, Array, Object, DOM, Event, API, Async/Await, Module, Advanced.

Elektronika/Komponen → Resistor, Capacitor, Diode, Transistor, MOSFET, IC, Relay, Transformer, Fuse, Switch, Connector, Sensor, Motor, Optocoupler, SCR, TRIAC, IGBT, Varistor.

Elektronika/Mikrokontroler → Arduino, ESP8266, ESP32, STM32, AVR, PIC, Raspberry Pi, GPIO, PWM, ADC, UART, I2C, SPI.

Hardware/Networking → LAN, Ethernet, WiFi, Bluetooth, Router, Modem, Access Point, IP, DNS, Internet.
