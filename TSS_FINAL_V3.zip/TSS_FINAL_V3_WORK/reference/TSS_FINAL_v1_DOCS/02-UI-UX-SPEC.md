# TSS UI/UX Specification

## Design language
Modern, minimal, technology-focused, professional, dark-first, responsive.

## Layout
Desktop: Header → Sidebar + Main → Footer.
Mobile: Header + Drawer/Bottom navigation → Main → Footer.

## Header
Logo, brand, global search, notification (authenticated), profile/login, mobile menu.

## Sidebar
HOME
BELAJAR
- Coding & Programming
- Elektronika
- Hardware & Software
MATERI
TUTORIAL
PROBLEM SOLVED
TOOLS
SHOP
MY LEARNING
- Progress
- Bookmark
- History
ACCOUNT
- Profile
- Settings

Admin memiliki shell terpisah.

## Design tokens
- background: near-black
- surface: dark gray
- surface elevated: darker/lighter card layer
- text primary: white-ish
- text secondary: muted gray
- border: low-contrast gray
- accent: single TSS accent, configurable
- focus: visible keyboard focus ring

## Accessibility
- Semantic HTML
- Keyboard navigation
- Focus visible
- Contrast compliant
- Reduced motion support
- Form labels/errors
- Accessible dialogs and menus

## Core pages
/
/search
/learn
/learn/[category]
/materials
/materials/[slug]
/tutorials
/tutorials/[slug]
/problems
/problems/[slug]
/tools
/tools/[tool]
/profile
/progress
/bookmarks
/settings
/auth/login
/auth/register
/admin/*
