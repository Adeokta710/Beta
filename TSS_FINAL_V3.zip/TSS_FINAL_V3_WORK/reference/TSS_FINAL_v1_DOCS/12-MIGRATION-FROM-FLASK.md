# Migration Mapping from legacy TSS

Legacy app.py/routes/services/models → apps/api-server/src/modules
Legacy templates → apps/web-client/src/app and components
Legacy static CSS/JS → styles/components/lib
Legacy static images → web public/assets
Legacy Python models → Prisma schema + shared types
Legacy SQLite → PostgreSQL migration/import script
Legacy env → documented env variables + secret manager

Migration rule: preserve business behavior first; improve boundaries second; change UX intentionally, not accidentally.
