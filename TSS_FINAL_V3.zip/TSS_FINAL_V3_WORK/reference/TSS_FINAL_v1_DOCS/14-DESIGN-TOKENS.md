# Design Tokens

```ts
export const tokens = {
  radius: { sm: '0.375rem', md: '0.625rem', lg: '0.875rem', xl: '1.25rem' },
  spacing: { xs: '0.25rem', sm: '0.5rem', md: '1rem', lg: '1.5rem', xl: '2rem' },
  typography: { body: 'Inter/system-ui', mono: 'JetBrains Mono/monospace' },
};
```

Color values are intentionally configurable through CSS variables so the TSS accent can evolve without rewriting components.
