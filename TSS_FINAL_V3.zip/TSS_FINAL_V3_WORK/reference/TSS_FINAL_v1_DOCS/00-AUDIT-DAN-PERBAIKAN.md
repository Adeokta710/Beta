# Audit dan Perbaikan Rancangan TSS

## Yang dipertahankan dari rancangan sumber
- Nama Technology Study Surabaya (TSS)
- Tagline: “Ayo Arek-Arek Suroboyo, Belajar Teknologi mulai Saiki”
- Learning platform, bukan blog
- Header + sidebar + main content + footer
- Mobile drawer/navigation
- Materi, Tutorial, Problem Solved, Tools, Search, Profile, Progress, Bookmark, Shop, Admin
- Domain belajar: Coding & Programming, Elektronika, Hardware & Software

## Perbaikan utama
1. Navigation dipisahkan dari taxonomy dan content.
2. Sidebar tidak menampilkan seluruh taxonomy yang dalam; detail kategori tampil di halaman kategori.
3. Backend menggunakan modular monolith NestJS terlebih dahulu, bukan microservices penuh.
4. Kubernetes hanya fase scale-up.
5. Authentication menggunakan short-lived access token + rotating refresh token berbasis HttpOnly Secure cookie.
6. Tambahkan audit log, session/revocation, content versioning, media metadata, notification, search indexing, dan soft-delete policy.
7. Tidak ada klaim “100% aman”; targetnya defense-in-depth dan security testing berkelanjutan.
8. Secret produksi tidak pernah dimasukkan ke repository atau docker-compose.
9. Semua endpoint admin wajib RBAC + audit log.
10. Content editor mendukung draft/review/publish/archive.

## Risiko rancangan lama
- Sidebar terlalu dalam.
- Beberapa dokumen mencampur NestJS modular dengan istilah microservice.
- Contoh Docker memakai credential plaintext; diperbaiki menjadi environment/secret.
- `contentJson` yang langsung `JSON.parse()` perlu validasi schema sebelum disimpan.
- Rate limiting tidak cukup hanya login; perlu endpoint sensitif lain.
- Shop dan subscription harus dibuat modular karena belum menjadi prioritas konten.
