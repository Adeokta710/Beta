# Database Design

## Core entities
User, Role, Session/RefreshToken, Category, Tag, Material, Tutorial, Problem, Quiz, Question, Answer, Progress, Bookmark, LearningHistory, Tool, Product, Comment, Media, Notification, AuditLog, Setting.

## Rules
- UUID primary keys.
- Unique slugs where appropriate.
- Foreign keys with deliberate delete behavior.
- Index search/filter fields.
- Timestamps everywhere.
- Soft delete only where audit/history matters.
- Content versioning for published content.
- Never store raw passwords or raw refresh tokens.

## Search
Start with PostgreSQL full-text/trigram search; introduce dedicated search engine only when needed.
