# Design v2 Changes

- Navigation and taxonomy separated.
- Modular monolith selected as initial backend architecture.
- Kubernetes/microservices moved to scale-up phase.
- Security claims changed from absolute guarantee to measurable defense-in-depth.
- Refresh sessions/revocation and audit logging added.
- Content workflow and revision/versioning added.
- Secret handling corrected.
- Content JSON validation requirement added.
- Search strategy phased: PostgreSQL first, dedicated engine later.
- Accessibility and reduced-motion requirements added.
- Testing gates and E2E critical flows added.
- Admin/CMS preview, review, publish, revision, audit flow added.
