# Testing & QA

## Gates
1. format/lint
2. typecheck
3. unit tests
4. API integration tests
5. database migration test
6. E2E critical flows
7. accessibility smoke test
8. dependency/security scan
9. production build
10. Docker smoke test

## Critical E2E
- Register/login/logout
- Refresh rotation
- RBAC admin rejection/allow
- Search
- Open material
- Bookmark
- Progress update
- Publish content
- Tool calculation
- Mobile navigation

## Error policy
No blank page on recoverable API errors. Use loading/empty/error states. Error boundaries must provide recovery action.
