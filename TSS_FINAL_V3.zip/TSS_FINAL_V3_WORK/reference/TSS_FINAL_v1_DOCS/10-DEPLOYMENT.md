# Deployment Blueprint

## Initial production
Web + API containers, PostgreSQL, Redis, NGINX.

## Environment
Use `.env.example` only as documentation. Production secrets are injected by the deployment environment.

Required examples:
DATABASE_URL
REDIS_URL
JWT_SECRET / signing key material
WEB_ORIGIN
API_ORIGIN

## NGINX
/ → web
/api/ → api
health endpoints protected appropriately.

## Observability
Structured API logs, request IDs, metrics, health/readiness checks. Prometheus/Grafana optional initially; Sentry or equivalent for error tracking.

## Scale-up
Kubernetes, separate services, queues, dedicated search, object storage/CDN only when required by measured load.
