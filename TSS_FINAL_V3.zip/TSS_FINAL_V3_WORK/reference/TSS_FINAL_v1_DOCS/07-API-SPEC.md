# API Contract (initial)

Base: /api/v1

## Health
GET /health
GET /ready

## Auth
POST /auth/register
POST /auth/login
POST /auth/refresh
POST /auth/logout
POST /auth/logout-all
GET /auth/me

## Learning
GET /learning/materials
GET /learning/materials/:slug
POST /learning/materials (ADMIN/INSTRUCTOR)
PATCH /learning/materials/:id
POST /learning/materials/:id/publish

## Tutorials / Problems
GET /tutorials
GET /tutorials/:slug
GET /problems
GET /problems/:slug

## Learning state
GET /me/progress
PUT /me/progress/:contentId
GET /me/bookmarks
PUT /me/bookmarks/:contentId
DELETE /me/bookmarks/:contentId

## Search
GET /search?q=&type=&category=&page=

## Admin
CRUD categories/content/users/settings + audit log access, all protected by RBAC and policy checks.

## API conventions
- JSON responses
- RFC 7807-style errors or consistent error envelope
- Pagination cursor/limit
- DTO/schema validation
- Request ID / trace ID
- No sensitive fields in responses
