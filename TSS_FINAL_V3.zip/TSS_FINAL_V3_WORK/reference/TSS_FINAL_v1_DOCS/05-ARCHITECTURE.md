# Architecture v2

```text
                         Internet
                            |
                         NGINX
                     /              \
                 Web Next.js       API NestJS
                                      |
                         +------------+------------+
                         |                         |
                    PostgreSQL                   Redis
                         |
                    Object Storage
```

## Monorepo
apps/web-client
apps/api-server
apps/admin-panel (optional separate app; can be deferred)
packages/database
packages/shared-types
packages/ui-system
infra/docker
infra/nginx
infra/prometheus
.github/workflows

## Backend approach
Modular monolith. Modules: auth, users, learning, categories, tutorials, problems, quiz, tools, search, bookmarks, progress, shop, admin, audit.

## Why
Keeps deployment and debugging simple while preserving domain boundaries. Microservices/Kubernetes can be introduced only when measured scale or team boundaries justify them.
