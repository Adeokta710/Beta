# Implementation Roadmap

Phase 0 Architecture freeze
Phase 1 Monorepo foundation
Phase 2 PostgreSQL/Prisma + migrations + seed structure
Phase 3 NestJS modules
Phase 4 UI system + public web
Phase 5 Auth/RBAC/security hardening
Phase 6 Admin/CMS
Phase 7 Search + progress/bookmarks
Phase 8 QA/E2E/accessibility
Phase 9 Docker/NGINX/observability
Phase 10 Production deployment
Phase 11 Security review + release

Content authoring is intentionally late-stage; the source plan also places content toward the end.
