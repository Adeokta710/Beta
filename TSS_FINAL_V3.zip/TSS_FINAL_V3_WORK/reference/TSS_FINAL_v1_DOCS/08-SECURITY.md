# Security Blueprint

## Authentication
- Password hashing with Argon2id preferred; bcrypt acceptable if policy requires it.
- Access token short-lived.
- Refresh token rotated and stored only in HttpOnly, Secure, SameSite cookie.
- Store refresh-token hash/server-side session metadata for revocation.
- Logout and logout-all support.

## Authorization
RBAC: USER, INSTRUCTOR, ADMIN, SUPERADMIN. Add resource-level policy checks where needed.

## Web protections
- TLS in production
- Strict CORS allowlist
- CSP
- HSTS
- X-Content-Type-Options
- Referrer-Policy
- Permissions-Policy
- CSRF strategy appropriate to cookie auth
- Input validation and output encoding
- Upload type/size/content validation
- SSRF-safe outbound requests

## Abuse protection
Redis-backed rate limiting on login, registration, password reset, search, quiz submission, comments, and other abuse-prone endpoints.

## Operational security
- Secrets via environment/secret manager.
- No credentials in git.
- Dependency audit.
- SAST/secret scan.
- Container scan.
- Database backups and restore test.
- Audit log for privileged actions.

## Reality check
No system can honestly be guaranteed 100% secure or error-free. Release criteria should be measurable: tests green, vulnerability policy met, backup restore verified, monitoring active, and rollback available.
