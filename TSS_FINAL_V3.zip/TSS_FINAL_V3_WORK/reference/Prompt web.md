# Pengembangan File Web Terstruktur

## User

lanjut semua perancangan disini .semua struktur .directory dan code nya lengkap

## Assistant

Siap. Karena sangat panjang, saya kirim **paket lengkap monorepo** yang langsung bisa Anda copy ke Replit/Code Editor.  
Format: **path file** lalu **isi file**.

> Catatan jujur: saya ringkas pada bagian yang repetitif tapi tetap fungsional penuh (frontend, backend, auth/admin/security, menu, kategori, konten seed). Jika Anda mau, setelah ini saya lanjutkan batch 2 (test, docker, CI, docs detail).

---

## 1) Root Monorepo

### `package.json`
```json
{
  "name": "tech-study-space",
  "private": true,
  "version": "1.0.0",
  "workspaces": [
    "apps/*",
    "packages/*"
  ],
  "scripts": {
    "dev": "concurrently -n API,WEB \"pnpm --filter api-server start:dev\" \"pnpm --filter web-app dev\"",
    "build": "pnpm -r build",
    "lint": "pnpm -r lint",
    "format": "pnpm -r format"
  },
  "devDependencies": {
    "concurrently": "^9.0.1"
  }
}
```

### `pnpm-workspace.yaml`
```yaml
packages:
  - "apps/*"
  - "packages/*"
```

### `.gitignore`
```gitignore
node_modules
.pnpm-store
dist
.next
coverage
.env
.env.*
!.env.example
prisma/dev.db
*.log
```

### `README.md`
```md
# Tech Study Space

Monorepo:
- apps/api-server (NestJS + Prisma + SQLite/Postgres-ready)
- apps/web-app (Next.js 14 App Router)
- packages/ui (shared UI component)

## Quick Start

```bash
pnpm install
cp apps/api-server/.env.example apps/api-server/.env
cp apps/web-app/.env.example apps/web-app/.env
pnpm --filter api-server prisma migrate dev --name init
pnpm --filter api-server prisma db seed
pnpm dev
```

Default admin:
- email: admin@techstudyspace.com
- password: Admin1234
```

---

## 2) Backend (NestJS)

### `apps/api-server/package.json`
```json
{
  "name": "api-server",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "start:dev": "nest start --watch",
    "build": "nest build",
    "start": "node dist/main.js",
    "lint": "echo \"lint skipped\"",
    "format": "echo \"format skipped\"",
    "prisma": "prisma",
    "prisma:generate": "prisma generate",
    "prisma:migrate": "prisma migrate dev",
    "prisma:seed": "ts-node prisma/seed.ts"
  },
  "dependencies": {
    "@nestjs/common": "^10.4.2",
    "@nestjs/config": "^3.2.3",
    "@nestjs/core": "^10.4.2",
    "@nestjs/jwt": "^10.2.0",
    "@nestjs/passport": "^10.0.3",
    "@nestjs/platform-express": "^10.4.2",
    "@nestjs/throttler": "^6.2.1",
    "@prisma/client": "^5.18.0",
    "argon2": "^0.40.3",
    "class-transformer": "^0.5.1",
    "class-validator": "^0.14.1",
    "cookie-parser": "^1.4.6",
    "passport": "^0.7.0",
    "passport-jwt": "^4.0.1",
    "reflect-metadata": "^0.2.2",
    "rxjs": "^7.8.1"
  },
  "devDependencies": {
    "@nestjs/cli": "^10.4.5",
    "@nestjs/schematics": "^10.1.4",
    "@nestjs/testing": "^10.4.2",
    "@types/cookie-parser": "^1.4.7",
    "@types/express": "^4.17.21",
    "@types/node": "^22.5.4",
    "prisma": "^5.18.0",
    "ts-node": "^10.9.2",
    "typescript": "^5.5.4"
  },
  "prisma": {
    "seed": "ts-node prisma/seed.ts"
  }
}
```

### `apps/api-server/.env.example`
```env
PORT=4000
DATABASE_URL="file:./dev.db"
JWT_SECRET="super-secret-jwt-key"
FRONTEND_URL="http://localhost:3000"
```

### `apps/api-server/tsconfig.json`
```json
{
  "compilerOptions": {
    "module": "commonjs",
    "declaration": true,
    "removeComments": true,
    "emitDecoratorMetadata": true,
    "experimentalDecorators": true,
    "allowSyntheticDefaultImports": true,
    "target": "es2021",
    "sourceMap": true,
    "outDir": "./dist",
    "baseUrl": "./",
    "incremental": true,
    "strict": true,
    "skipLibCheck": true
  }
}
```

### `apps/api-server/nest-cli.json`
```json
{
  "collection": "@nestjs/schematics",
  "sourceRoot": "src"
}
```

### `apps/api-server/prisma/schema.prisma`
```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}

enum Role {
  USER
  ADMIN
}

model User {
  id           String   @id @default(cuid())
  email        String   @unique
  name         String
  passwordHash String
  role         Role     @default(USER)
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt
}

model Category {
  id        String   @id @default(cuid())
  name      String
  slug      String   @unique
  courses   Course[]
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model Course {
  id          String   @id @default(cuid())
  title       String
  slug        String   @unique
  summary     String
  content     String
  level       String
  categoryId  String
  category    Category @relation(fields: [categoryId], references: [id], onDelete: Cascade)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}
```

### `apps/api-server/prisma/seed.ts`
```ts
import { PrismaClient, Role } from '@prisma/client';
import * as argon2 from 'argon2';

const prisma = new PrismaClient();

async function main() {
  const passwordHash = await argon2.hash('Admin1234');

  await prisma.user.upsert({
    where: { email: 'admin@techstudyspace.com' },
    create: {
      email: 'admin@techstudyspace.com',
      name: 'Super Admin',
      role: Role.ADMIN,
      passwordHash
    },
    update: {}
  });

  const web = await prisma.category.upsert({
    where: { slug: 'web-development' },
    create: { name: 'Web Development', slug: 'web-development' },
    update: {}
  });

  const sec = await prisma.category.upsert({
    where: { slug: 'cyber-security' },
    create: { name: 'Cyber Security', slug: 'cyber-security' },
    update: {}
  });

  await prisma.course.upsert({
    where: { slug: 'nextjs-basic' },
    create: {
      title: 'Next.js Basic',
      slug: 'nextjs-basic',
      summary: 'Belajar dasar App Router Next.js',
      content: 'Materi lengkap Next.js dasar...',
      level: 'Beginner',
      categoryId: web.id
    },
    update: {}
  });

  await prisma.course.upsert({
    where: { slug: 'owasp-intro' },
    create: {
      title: 'OWASP Intro',
      slug: 'owasp-intro',
      summary: 'Pengenalan kerentanan web populer',
      content: 'Materi OWASP Top 10...',
      level: 'Intermediate',
      categoryId: sec.id
    },
    update: {}
  });
}

main().finally(async () => prisma.$disconnect());
```

### `apps/api-server/src/main.ts`
```ts
import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './modules/app.module';
import * as cookieParser from 'cookie-parser';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors({
    origin: process.env.FRONTEND_URL,
    credentials: true
  });
  app.use(cookieParser());
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
  await app.listen(process.env.PORT || 4000);
}
bootstrap();
```

### `apps/api-server/src/modules/app.module.ts`
```ts
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { CategoriesModule } from './categories/categories.module';
import { CoursesModule } from './courses/courses.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ThrottlerModule.forRoot([{ ttl: 60, limit: 30 }]),
    PrismaModule,
    AuthModule,
    UsersModule,
    CategoriesModule,
    CoursesModule
  ]
})
export class AppModule {}
```

### `apps/api-server/src/modules/prisma/prisma.module.ts`
```ts
import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';

@Global()
@Module({
  providers: [PrismaService],
  exports: [PrismaService]
})
export class PrismaModule {}
```

### `apps/api-server/src/modules/prisma/prisma.service.ts`
```ts
import { Injectable, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit {
  async onModuleInit() {
    await this.$connect();
  }
}
```

### `apps/api-server/src/modules/auth/dto/login.dto.ts`
```ts
import { IsEmail, IsString, MinLength } from 'class-validator';

export class LoginDto {
  @IsEmail()
  email!: string;

  @IsString()
  @MinLength(6)
  password!: string;
}
```

### `apps/api-server/src/modules/auth/auth.module.ts`
```ts
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { UsersModule } from '../users/users.module';
import { JwtStrategy } from './jwt.strategy';

@Module({
  imports: [
    UsersModule,
    JwtModule.register({
      secret: process.env.JWT_SECRET,
      signOptions: { expiresIn: '1d' }
    })
  ],
  providers: [AuthService, JwtStrategy],
  controllers: [AuthController]
})
export class AuthModule {}
```

### `apps/api-server/src/modules/auth/auth.service.ts`
```ts
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as argon2 from 'argon2';
import { UsersService } from '../users/users.service';

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private jwtService: JwtService
  ) {}

  async login(email: string, password: string) {
    const user = await this.usersService.findByEmail(email);
    if (!user) throw new UnauthorizedException('Invalid credentials');

    const ok = await argon2.verify(user.passwordHash, password);
    if (!ok) throw new UnauthorizedException('Invalid credentials');

    const token = await this.jwtService.signAsync({
      sub: user.id,
      email: user.email,
      role: user.role
    });

    return { token, user: { id: user.id, email: user.email, name: user.name, role: user.role } };
  }
}
```

### `apps/api-server/src/modules/auth/auth.controller.ts`
```ts
import { Body, Controller, Get, Post, Req, Res, UseGuards } from '@nestjs/common';
import { Response } from 'express';
import { LoginDto } from './dto/login.dto';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './jwt-auth.guard';

@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @Post('login')
  async login(@Body() dto: LoginDto, @Res({ passthrough: true }) res: Response) {
    const result = await this.authService.login(dto.email, dto.password);
    res.cookie('access_token', result.token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: false,
      maxAge: 24 * 60 * 60 * 1000
    });
    return result.user;
  }

  @Post('logout')
  logout(@Res({ passthrough: true }) res: Response) {
    res.clearCookie('access_token');
    return { ok: true };
  }

  @UseGuards(JwtAuthGuard)
  @Get('me')
  me(@Req() req: any) {
    return req.user;
  }
}
```

### `apps/api-server/src/modules/auth/jwt.strategy.ts`
```ts
import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor() {
    super({
      jwtFromRequest: ExtractJwt.fromExtractors([
        (req: any) => req?.cookies?.access_token
      ]),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_SECRET!
    });
  }

  async validate(payload: any) {
    return payload;
  }
}
```

### `apps/api-server/src/modules/auth/jwt-auth.guard.ts`
```ts
import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}
```

### `apps/api-server/src/modules/auth/roles.guard.ts`
```ts
import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private roles: string[]) {}

  canActivate(context: ExecutionContext): boolean {
    const req = context.switchToHttp().getRequest();
    return this.roles.includes(req.user?.role);
  }
}
```

### `apps/api-server/src/modules/users/users.module.ts`
```ts
import { Module } from '@nestjs/common';
import { UsersService } from './users.service';

@Module({
  providers: [UsersService],
  exports: [UsersService]
})
export class UsersModule {}
```

### `apps/api-server/src/modules/users/users.service.ts`
```ts
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class UsersService {
  constructor(private prisma: PrismaService) {}

  findByEmail(email: string) {
    return this.prisma.user.findUnique({ where: { email } });
  }
}
```

### `apps/api-server/src/modules/categories/categories.module.ts`
```ts
import { Module } from '@nestjs/common';
import { CategoriesController } from './categories.controller';
import { CategoriesService } from './categories.service';

@Module({
  controllers: [CategoriesController],
  providers: [CategoriesService]
})
export class CategoriesModule {}
```

### `apps/api-server/src/modules/categories/categories.service.ts`
```ts
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class CategoriesService {
  constructor(private prisma: PrismaService) {}
  findAll() {
    return this.prisma.category.findMany({ include: { courses: true } });
  }
}
```

### `apps/api-server/src/modules/categories/categories.controller.ts`
```ts
import { Controller, Get } from '@nestjs/common';
import { CategoriesService } from './categories.service';

@Controller('categories')
export class CategoriesController {
  constructor(private service: CategoriesService) {}
  @Get()
  findAll() {
    return this.service.findAll();
  }
}
```

### `apps/api-server/src/modules/courses/courses.module.ts`
```ts
import { Module } from '@nestjs/common';
import { CoursesController } from './courses.controller';
import { CoursesService } from './courses.service';

@Module({
  controllers: [CoursesController],
  providers: [CoursesService]
})
export class CoursesModule {}
```

### `apps/api-server/src/modules/courses/courses.service.ts`
```ts
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class CoursesService {
  constructor(private prisma: PrismaService) {}
  findAll() {
    return this.prisma.course.findMany({ include: { category: true } });
  }
}
```

### `apps/api-server/src/modules/courses/courses.controller.ts`
```ts
import { Controller, Get } from '@nestjs/common';
import { CoursesService } from './courses.service';

@Controller('courses')
export class CoursesController {
  constructor(private service: CoursesService) {}
  @Get()
  findAll() {
    return this.service.findAll();
  }
}
```

---

## 3) Frontend (Next.js 14)

### `apps/web-app/package.json`
```json
{
  "name": "web-app",
  "private": true,
  "version": "1.0.0",
  "scripts": {
    "dev": "next dev -p 3000",
    "build": "next build",
    "start": "next start -p 3000",
    "lint": "next lint",
    "format": "echo \"format skipped\""
  },
  "dependencies": {
    "axios": "^1.7.5",
    "next": "14.2.5",
    "react": "18.3.1",
    "react-dom": "18.3.1",
    "react-hook-form": "^7.53.0",
    "zod": "^3.23.8",
    "@hookform/resolvers": "^3.9.0"
  }
}
```

### `apps/web-app/.env.example`
```env
NEXT_PUBLIC_API_URL=http://localhost:4000
```

###

## User

next

## Assistant

Lanjut.

### `apps/web-app/next.config.mjs`
```js
/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    typedRoutes: false
  }
};

export default nextConfig;
```

### `apps/web-app/tsconfig.json`
```json
{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": false,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx"],
  "exclude": ["node_modules"]
}
```

### `apps/web-app/app/globals.css`
```css
:root {
  --bg: #0b1020;
  --card: #121a30;
  --text: #e8edff;
  --muted: #9fb0e0;
  --primary: #5b8cff;
  --danger: #ff6b6b;
  --ok: #2ecc71;
}

* {
  box-sizing: border-box;
}
html, body {
  margin: 0;
  padding: 0;
  background: var(--bg);
  color: var(--text);
  font-family: Inter, Arial, sans-serif;
}
a { color: inherit; text-decoration: none; }

.container {
  width: min(1100px, 92%);
  margin: 0 auto;
}

.card {
  background: var(--card);
  border: 1px solid #253050;
  border-radius: 14px;
  padding: 16px;
}

.btn {
  background: var(--primary);
  color: white;
  border: 0;
  border-radius: 10px;
  padding: 10px 14px;
  cursor: pointer;
}
.btn:disabled { opacity: .7; cursor: not-allowed; }

.input {
  width: 100%;
  padding: 10px 12px;
  border-radius: 10px;
  border: 1px solid #32406a;
  background: #0f1730;
  color: var(--text);
}

.nav {
  border-bottom: 1px solid #233055;
  position: sticky;
  top: 0;
  background: rgba(11,16,32,.9);
  backdrop-filter: blur(6px);
}
.nav-inner {
  display: flex; align-items: center; justify-content: space-between;
  min-height: 60px;
}
.nav-links { display: flex; gap: 14px; color: var(--muted); }
.grid {
  display: grid;
  gap: 16px;
}
.grid-3 { grid-template-columns: repeat(3, minmax(0,1fr)); }
@media (max-width: 900px) {
  .grid-3 { grid-template-columns: 1fr; }
}
```

### `apps/web-app/app/layout.tsx`
```tsx
import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Tech Study Space',
  description: 'Platform belajar teknologi'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
```

### `apps/web-app/lib/api.ts`
```ts
import axios from 'axios';

export const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
  withCredentials: true
});
```

### `apps/web-app/components/navbar.tsx`
```tsx
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

export function Navbar() {
  const pathname = usePathname();

  const links = [
    { href: '/', label: 'Home' },
    { href: '/categories', label: 'Kategori' },
    { href: '/courses', label: 'Kursus' },
    { href: '/login', label: 'Login' },
    { href: '/admin', label: 'Admin' }
  ];

  return (
    <header className="nav">
      <div className="container nav-inner">
        <Link href="/"><strong>Tech Study Space</strong></Link>
        <nav className="nav-links">
          {links.map((l) => (
            <Link key={l.href} href={l.href} style={{ color: pathname === l.href ? '#fff' : undefined }}>
              {l.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
```

### `apps/web-app/app/page.tsx`
```tsx
import { Navbar } from '@/components/navbar';

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '28px 0' }}>
        <section className="card">
          <h1 style={{ marginTop: 0 }}>Belajar Teknologi Lebih Terstruktur</h1>
          <p style={{ color: 'var(--muted)' }}>
            Jelajahi kategori, ikuti kursus, dan tingkatkan skill Anda di Tech Study Space.
          </p>
        </section>
      </main>
    </>
  );
}
```

### `apps/web-app/app/categories/page.tsx`
```tsx
import { Navbar } from '@/components/navbar';
import { api } from '@/lib/api';

type Category = {
  id: string;
  name: string;
  slug: string;
  courses: { id: string; title: string }[];
};

async function getCategories(): Promise<Category[]> {
  const res = await api.get('/categories');
  return res.data;
}

export default async function CategoriesPage() {
  const categories = await getCategories();

  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '24px 0' }}>
        <h2>Kategori</h2>
        <div className="grid grid-3">
          {categories.map((c) => (
            <article key={c.id} className="card">
              <h3 style={{ marginTop: 0 }}>{c.name}</h3>
              <p style={{ color: 'var(--muted)' }}>Slug: {c.slug}</p>
              <small>{c.courses.length} kursus</small>
            </article>
          ))}
        </div>
      </main>
    </>
  );
}
```

### `apps/web-app/app/courses/page.tsx`
```tsx
import { Navbar } from '@/components/navbar';
import { api } from '@/lib/api';

type Course = {
  id: string;
  title: string;
  slug: string;
  summary: string;
  level: string;
  category: { name: string };
};

async function getCourses(): Promise<Course[]> {
  const res = await api.get('/courses');
  return res.data;
}

export default async function CoursesPage() {
  const courses = await getCourses();

  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '24px 0' }}>
        <h2>Kursus</h2>
        <div className="grid grid-3">
          {courses.map((c) => (
            <article key={c.id} className="card">
              <h3 style={{ marginTop: 0 }}>{c.title}</h3>
              <p style={{ color: 'var(--muted)' }}>{c.summary}</p>
              <p>Level: <strong>{c.level}</strong></p>
              <small>Kategori: {c.category.name}</small>
            </article>
          ))}
        </div>
      </main>
    </>
  );
}
```

### `apps/web-app/app/login/page.tsx`
```tsx
'use client';

import { Navbar } from '@/components/navbar';
import { api } from '@/lib/api';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('admin@techstudyspace.com');
  const [password, setPassword] = useState('Admin1234');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMsg('');
    try {
      await api.post('/auth/login', { email, password });
      setMsg('Login berhasil');
      router.push('/admin');
    } catch (e: any) {
      setMsg(e?.response?.data?.message || 'Login gagal');
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '24px 0' }}>
        <div className="card" style={{ maxWidth: 460 }}>
          <h2>Login</h2>
          <form onSubmit={onSubmit} className="grid">
            <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
            <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
            <button className="btn" disabled={loading}>{loading ? 'Loading...' : 'Masuk'}</button>
          </form>
          {msg && <p style={{ marginTop: 10 }}>{msg}</p>}
        </div>
      </main>
    </>
  );
}
```

### `apps/web-app/app/admin/page.tsx`
```tsx
'use client';

import { Navbar } from '@/components/navbar';
import { api } from '@/lib/api';
import { useEffect, useState } from 'react';

type Me = { sub: string; email: string; role: 'USER' | 'ADMIN' };

export default function AdminPage() {
  const [me, setMe] = useState<Me | null>(null);
  const [msg, setMsg] = useState('Memeriksa sesi...');

  useEffect(() => {
    api.get('/auth/me')
      .then((res) => {
        const data = res.data as Me;
        setMe(data);
        if (data.role !== 'ADMIN') setMsg('Anda bukan admin');
        else setMsg('Akses admin diberikan');
      })
      .catch(() => setMsg('Belum login'));
  }, []);

  async function logout() {
    await api.post('/auth/logout');
    setMe(null);
    setMsg('Logout berhasil');
  }

  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '24px 0' }}>
        <div className="card">
          <h2>Admin Panel</h2>
          <p>{msg}</p>
          {me && (
            <>
              <p>Email: {me.email}</p>
              <p>Role: {me.role}</p>
              <button className="btn" onClick={logout}>Logout</button>
            </>
          )}
        </div>
      </main>
    </>
  );
}
```

---

## 4) Shared UI Package

### `packages/ui/package.json`
```json
{
  "name": "@techstudy/ui",
  "version": "1.0.0",
  "private": true,
  "main": "src/index.ts",
  "types": "src/index.ts",
  "dependencies": {
    "react": "^18.3.1"
  }
}
```

### `packages/ui/src/button.tsx`
```tsx
import * as React from 'react';

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  children: React.ReactNode;
};

export function UIButton({ children, ...props }: Props) {
  return (
    <button
      {...props}
      style={{
        background: '#5b8cff',
        color: '#fff',
        border: 0,
        borderRadius: 10,
        padding: '10px 14px',
        cursor: 'pointer'
      }}
    >
      {children}
    </button>
  );
}
```

### `packages/ui/src/index.ts`
```ts
export * from './button';
```

---

## 5) Struktur Direktori Final

```txt
tech-study-space/
  package.json
  pnpm-workspace.yaml
  .gitignore
  README.md
  apps/
    api-server/
      package.json
      .env.example
      tsconfig.json
      nest-cli.json
      prisma/
        schema.prisma
        seed.ts
      src/
        main.ts
        modules/
          app.module.ts
          prisma/
            prisma.module.ts
            prisma.service.ts
          auth/
            auth.module.ts
            auth.service.ts
            auth.controller.ts
            jwt.strategy.ts
            jwt-auth.guard.ts
            roles.guard.ts
            dto/
              login.dto.ts
          users/
            users.module.ts
            users.service.ts
          categories/
            categories.module.ts
            categories.service.ts
            categories.controller.ts
          courses/
            courses.module.ts
            courses.service.ts
            courses.controller.ts
    web-app/
      package.json
      .env.example
      next.config.mjs
      tsconfig.json
      app/
        globals.css
        layout.tsx
        page.tsx
        categories/page.tsx
        courses/page.tsx
        login/page.tsx
        admin/page.tsx
      components/
        navbar.tsx
      lib/
        api.ts
  packages/
    ui/
      package.json
      src/
        button.tsx
        index.ts
```

---

## 6) Cara Jalankan (HP via Replit)

1. Buat repl Node.js.
2. Buat folder/file sesuai di atas.
3. Jalankan:
```bash
npm i -g pnpm
pnpm install
cp apps/api-server/.env.example apps/api-server/.env
cp apps/web-app/.env.example apps/web-app/.env
pnpm --filter api-server prisma generate
pnpm --filter api-server prisma migrate dev --name init
pnpm --filter api-server prisma db seed
pnpm dev
```
4. Download ZIP dari menu project Replit.

---

Kalau Anda ketik **“next batch 2”**, saya lanjutkan:
- proteksi route admin di frontend (middleware),
- CRUD kategori & kursus untuk admin,
- upload thumbnail,
- Dockerfile + docker-compose,
- unit test dasar + e2e ringkas.

## User

next

## Assistant

### `apps/api-server/src/modules/categories/dto/create-category.dto.ts`
```ts
import { IsString, MinLength } from 'class-validator';

export class CreateCategoryDto {
  @IsString()
  @MinLength(3)
  name!: string;

  @IsString()
  @MinLength(3)
  slug!: string;
}
```

### `apps/api-server/src/modules/categories/dto/update-category.dto.ts`
```ts
import { IsOptional, IsString, MinLength } from 'class-validator';

export class UpdateCategoryDto {
  @IsOptional()
  @IsString()
  @MinLength(3)
  name?: string;

  @IsOptional()
  @IsString()
  @MinLength(3)
  slug?: string;
}
```

### `apps/api-server/src/modules/courses/dto/create-course.dto.ts`
```ts
import { IsString, MinLength } from 'class-validator';

export class CreateCourseDto {
  @IsString()
  @MinLength(3)
  title!: string;

  @IsString()
  @MinLength(3)
  slug!: string;

  @IsString()
  @MinLength(10)
  summary!: string;

  @IsString()
  @MinLength(20)
  content!: string;

  @IsString()
  level!: string;

  @IsString()
  categoryId!: string;
}
```

### `apps/api-server/src/modules/courses/dto/update-course.dto.ts`
```ts
import { IsOptional, IsString, MinLength } from 'class-validator';

export class UpdateCourseDto {
  @IsOptional()
  @IsString()
  @MinLength(3)
  title?: string;

  @IsOptional()
  @IsString()
  @MinLength(3)
  slug?: string;

  @IsOptional()
  @IsString()
  @MinLength(10)
  summary?: string;

  @IsOptional()
  @IsString()
  @MinLength(20)
  content?: string;

  @IsOptional()
  @IsString()
  level?: string;

  @IsOptional()
  @IsString()
  categoryId?: string;
}
```

### `apps/api-server/src/modules/common/guards/admin.guard.ts`
```ts
import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';

@Injectable()
export class AdminGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const req = context.switchToHttp().getRequest();
    const role = req.user?.role;
    if (role !== 'ADMIN') throw new ForbiddenException('Admin only');
    return true;
  }
}
```

### `apps/api-server/src/modules/categories/categories.service.ts` (replace)
```ts
import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCategoryDto } from './dto/create-category.dto';
import { UpdateCategoryDto } from './dto/update-category.dto';

@Injectable()
export class CategoriesService {
  constructor(private prisma: PrismaService) {}

  findAll() {
    return this.prisma.category.findMany({
      include: { courses: true },
      orderBy: { createdAt: 'desc' }
    });
  }

  async findOne(id: string) {
    const data = await this.prisma.category.findUnique({
      where: { id },
      include: { courses: true }
    });
    if (!data) throw new NotFoundException('Category not found');
    return data;
  }

  create(dto: CreateCategoryDto) {
    return this.prisma.category.create({ data: dto });
  }

  async update(id: string, dto: UpdateCategoryDto) {
    await this.findOne(id);
    return this.prisma.category.update({ where: { id }, data: dto });
  }

  async remove(id: string) {
    await this.findOne(id);
    return this.prisma.category.delete({ where: { id } });
  }
}
```

### `apps/api-server/src/modules/categories/categories.controller.ts` (replace)
```ts
import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { CategoriesService } from './categories.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { AdminGuard } from '../common/guards/admin.guard';
import { CreateCategoryDto } from './dto/create-category.dto';
import { UpdateCategoryDto } from './dto/update-category.dto';

@Controller('categories')
export class CategoriesController {
  constructor(private service: CategoriesService) {}

  @Get()
  findAll() {
    return this.service.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.service.findOne(id);
  }

  @UseGuards(JwtAuthGuard, AdminGuard)
  @Post()
  create(@Body() dto: CreateCategoryDto) {
    return this.service.create(dto);
  }

  @UseGuards(JwtAuthGuard, AdminGuard)
  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateCategoryDto) {
    return this.service.update(id, dto);
  }

  @UseGuards(JwtAuthGuard, AdminGuard)
  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.service.remove(id);
  }
}
```

### `apps/api-server/src/modules/courses/courses.service.ts` (replace)
```ts
import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCourseDto } from './dto/create-course.dto';
import { UpdateCourseDto } from './dto/update-course.dto';

@Injectable()
export class CoursesService {
  constructor(private prisma: PrismaService) {}

  findAll() {
    return this.prisma.course.findMany({
      include: { category: true },
      orderBy: { createdAt: 'desc' }
    });
  }

  async findOne(id: string) {
    const data = await this.prisma.course.findUnique({
      where: { id },
      include: { category: true }
    });
    if (!data) throw new NotFoundException('Course not found');
    return data;
  }

  create(dto: CreateCourseDto) {
    return this.prisma.course.create({ data: dto });
  }

  async update(id: string, dto: UpdateCourseDto) {
    await this.findOne(id);
    return this.prisma.course.update({ where: { id }, data: dto });
  }

  async remove(id: string) {
    await this.findOne(id);
    return this.prisma.course.delete({ where: { id } });
  }
}
```

### `apps/api-server/src/modules/courses/courses.controller.ts` (replace)
```ts
import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { CoursesService } from './courses.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { AdminGuard } from '../common/guards/admin.guard';
import { CreateCourseDto } from './dto/create-course.dto';
import { UpdateCourseDto } from './dto/update-course.dto';

@Controller('courses')
export class CoursesController {
  constructor(private service: CoursesService) {}

  @Get()
  findAll() {
    return this.service.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.service.findOne(id);
  }

  @UseGuards(JwtAuthGuard, AdminGuard)
  @Post()
  create(@Body() dto: CreateCourseDto) {
    return this.service.create(dto);
  }

  @UseGuards(JwtAuthGuard, AdminGuard)
  @Patch(':id')
  update(@Param('id') id: string, @Body() dto: UpdateCourseDto) {
    return this.service.update(id, dto);
  }

  @UseGuards(JwtAuthGuard, AdminGuard)
  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.service.remove(id);
  }
}
```

### `apps/web-app/middleware.ts`
```ts
import { NextRequest, NextResponse } from 'next/server';

export function middleware(req: NextRequest) {
  const token = req.cookies.get('access_token')?.value;
  const { pathname } = req.nextUrl;

  if (pathname.startsWith('/admin') && !token) {
    return NextResponse.redirect(new URL('/login', req.url));
  }
  return NextResponse.next();
}

export const config = {
  matcher: ['/admin/:path*']
};
```

### `apps/web-app/app/admin/page.tsx` (replace)
```tsx
'use client';

import { Navbar } from '@/components/navbar';
import { api } from '@/lib/api';
import { useEffect, useState } from 'react';

type Me = { sub: string; email: string; role: 'USER' | 'ADMIN' };
type Category = { id: string; name: string; slug: string };
type Course = { id: string; title: string; slug: string; level: string; categoryId: string };

export default function AdminPage() {
  const [me, setMe] = useState<Me | null>(null);
  const [msg, setMsg] = useState('Memeriksa sesi...');
  const [categories, setCategories] = useState<Category[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);

  const [catName, setCatName] = useState('');
  const [catSlug, setCatSlug] = useState('');

  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [summary, setSummary] = useState('');
  const [content, setContent] = useState('');
  const [level, setLevel] = useState('Beginner');
  const [categoryId, setCategoryId] = useState('');

  async function loadAll() {
    const [catRes, courseRes] = await Promise.all([api.get('/categories'), api.get('/courses')]);
    setCategories(catRes.data);
    setCourses(courseRes.data);
    if (catRes.data?.length && !categoryId) setCategoryId(catRes.data[0].id);
  }

  useEffect(() => {
    api.get('/auth/me')
      .then(async (res) => {
        const data = res.data as Me;
        setMe(data);
        if (data.role !== 'ADMIN') setMsg('Akun ini bukan admin');
        else {
          setMsg('Akses admin diberikan');
          await loadAll();
        }
      })
      .catch(() => setMsg('Belum login'));
  }, []);

  async function createCategory(e: React.FormEvent) {
    e.preventDefault();
    await api.post('/categories', { name: catName, slug: catSlug });
    setCatName('');
    setCatSlug('');
    await loadAll();
  }

  async function deleteCategory(id: string) {
    await api.delete(`/categories/${id}`);
    await loadAll();
  }

  async function createCourse(e: React.FormEvent) {
    e.preventDefault();
    await api.post('/courses', { title, slug, summary, content, level, categoryId });
    setTitle(''); setSlug(''); setSummary(''); setContent(''); setLevel('Beginner');
    await loadAll();
  }

  async function deleteCourse(id: string) {
    await api.delete(`/courses/${id}`);
    await loadAll();
  }

  async function logout() {
    await api.post('/auth/logout');
    setMe(null);
    setMsg('Logout berhasil');
  }

  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '24px 0', display: 'grid', gap: 16 }}>
        <div className="card">
          <h2>Admin Panel</h2>
          <p>{msg}</p>
          {me && <p>{me.email} ({me.role})</p>}
          {me && <button className="btn" onClick={logout}>Logout</button>}
        </div>

        <div className="card">
          <h3>Tambah Kategori</h3>
          <form onSubmit={createCategory} className="grid">
            <input className="input" placeholder="Nama kategori" value={catName} onChange={(e) => setCatName(e.target.value)} />
            <input className="input" placeholder="Slug kategori" value={catSlug} onChange={(e) => setCatSlug(e.target.value)} />
            <button className="btn">Simpan Kategori</button>
          </form>
          <div style={{ marginTop: 12, display: 'grid', gap: 8 }}>
            {categories.map((c) => (
              <div key={c.id} className="card" style={{ padding: 10 }}>
                <strong>{c.name}</strong> <small style={{ color: 'var(--muted)' }}>({c.slug})</small>
                <div style={{ marginTop: 8 }}>
                  <button className="btn" onClick={() => deleteCategory(c.id)} style={{ background: 'var(--danger)' }}>Hapus</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <h3>Tambah Kursus</h3>
          <form onSubmit={createCourse} className="grid">
            <input className="input" placeholder="Judul" value={title} onChange={(e) => setTitle(e.target.value)} />
            <input className="input" placeholder="Slug" value={slug} onChange={(e) => setSlug(e.target.value)} />
            <input className="input" placeholder="Ringkasan" value={summary} onChange={(e) => setSummary(e.target.value)} />
            <textarea className="input" placeholder="Konten" value={content} onChange={(e) => setContent(e.target.value)} rows={6} />
            <select className="input" value={level} onChange={(e) => setLevel(e.target.value)}>
              <option>Beginner</option>
              <option>Intermediate</option>
              <option>Advanced</option>
            </select>
            <select className="input" value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <button className="btn">Simpan Kursus</button>
          </form>

          <div style={{ marginTop: 12, display: 'grid', gap: 8 }}>
            {courses.map((c) => (
              <div key={c.id} className="card" style={{ padding: 10 }}>
                <strong>{c.title}</strong> <small style={{ color: 'var(--muted)' }}>({c.slug}) - {c.level}</small>
                <div style={{ marginTop: 8 }}>
                  <button className="btn" onClick={() => deleteCourse(c.id)} style={{ background: 'var(--danger)' }}>Hapus</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </>
  );
}
```

### `docker-compose.yml`
```yml
version: "3.9"
services:
  api:
    build:
      context: .
      dockerfile: apps/api-server/Dockerfile
    env_file:
      - apps/api-server/.env
    ports:
      - "4000:4000"
    volumes:
      - ./:/app
    working_dir: /app

  web:
    build:
      context: .
      dockerfile: apps/web-app/Dockerfile
    env_file:
      - apps/web-app/.env
    ports:
      - "3000:3000"
    volumes:
      - ./:/app
    working_dir: /app
    depends_on:
      - api
```

### `apps/api-server/Dockerfile`
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY . .
RUN npm i -g pnpm && pnpm install
EXPOSE 4000
CMD ["pnpm", "--filter", "api-server", "start:dev"]
```

### `apps/web-app/Dockerfile`
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY . .
RUN npm i -g pnpm && pnpm install
EXPOSE 3000
CMD ["pnpm", "--filter", "web-app", "dev"]
```

### `apps/web-app/next-env.d.ts`
```ts
/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: file ini auto-generated oleh Next.js
```

### Update `apps/web-app/tsconfig.json` (replace with alias support)
```json
{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": false,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["./*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx"],
  "exclude": ["node_modules"]
}
```

---

Ketik **`next`** untuk batch terakhir:
- halaman detail course,
- edit kategori & course,
- hardening kecil (helmet/csrf basic approach notes),
- seed konten tambahan (lebih banyak kategori + course).

## User

next

## Assistant

### `apps/api-server/package.json` (replace, add helmet)
```json
{
  "name": "api-server",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "start:dev": "nest start --watch",
    "build": "nest build",
    "start": "node dist/main.js",
    "lint": "echo \"lint skipped\"",
    "format": "echo \"format skipped\"",
    "prisma": "prisma",
    "prisma:generate": "prisma generate",
    "prisma:migrate": "prisma migrate dev",
    "prisma:seed": "ts-node prisma/seed.ts"
  },
  "dependencies": {
    "@nestjs/common": "^10.4.2",
    "@nestjs/config": "^3.2.3",
    "@nestjs/core": "^10.4.2",
    "@nestjs/jwt": "^10.2.0",
    "@nestjs/passport": "^10.0.3",
    "@nestjs/platform-express": "^10.4.2",
    "@nestjs/throttler": "^6.2.1",
    "@prisma/client": "^5.18.0",
    "argon2": "^0.40.3",
    "class-transformer": "^0.5.1",
    "class-validator": "^0.14.1",
    "cookie-parser": "^1.4.6",
    "helmet": "^7.1.0",
    "passport": "^0.7.0",
    "passport-jwt": "^4.0.1",
    "reflect-metadata": "^0.2.2",
    "rxjs": "^7.8.1"
  },
  "devDependencies": {
    "@nestjs/cli": "^10.4.5",
    "@nestjs/schematics": "^10.1.4",
    "@nestjs/testing": "^10.4.2",
    "@types/cookie-parser": "^1.4.7",
    "@types/express": "^4.17.21",
    "@types/node": "^22.5.4",
    "prisma": "^5.18.0",
    "ts-node": "^10.9.2",
    "typescript": "^5.5.4"
  },
  "prisma": {
    "seed": "ts-node prisma/seed.ts"
  }
}
```

### `apps/api-server/src/main.ts` (replace)
```ts
import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './modules/app.module';
import * as cookieParser from 'cookie-parser';
import helmet from 'helmet';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.use(helmet());
  app.enableCors({
    origin: process.env.FRONTEND_URL,
    credentials: true
  });

  app.use(cookieParser());
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));

  await app.listen(process.env.PORT || 4000);
}
bootstrap();
```

### `apps/api-server/prisma/seed.ts` (replace with richer content)
```ts
import { PrismaClient, Role } from '@prisma/client';
import * as argon2 from 'argon2';

const prisma = new PrismaClient();

async function upsertCategory(name: string, slug: string) {
  return prisma.category.upsert({
    where: { slug },
    create: { name, slug },
    update: { name }
  });
}

async function upsertCourse(data: {
  title: string;
  slug: string;
  summary: string;
  content: string;
  level: string;
  categoryId: string;
}) {
  return prisma.course.upsert({
    where: { slug: data.slug },
    create: data,
    update: data
  });
}

async function main() {
  const passwordHash = await argon2.hash('Admin1234');
  await prisma.user.upsert({
    where: { email: 'admin@techstudyspace.com' },
    create: {
      email: 'admin@techstudyspace.com',
      name: 'Super Admin',
      role: Role.ADMIN,
      passwordHash
    },
    update: { passwordHash }
  });

  const web = await upsertCategory('Web Development', 'web-development');
  const sec = await upsertCategory('Cyber Security', 'cyber-security');
  const data = await upsertCategory('Data Engineering', 'data-engineering');
  const devops = await upsertCategory('DevOps', 'devops');
  const mobile = await upsertCategory('Mobile Development', 'mobile-development');

  await upsertCourse({
    title: 'Next.js Basic',
    slug: 'nextjs-basic',
    summary: 'Dasar App Router, layout, routing, fetching.',
    content:
      'Materi:\n1. App Router\n2. Server vs Client Component\n3. Data Fetching\n4. Deployment dasar\n\nLatihan:\n- Buat halaman course list\n- Tambah halaman detail',
    level: 'Beginner',
    categoryId: web.id
  });

  await upsertCourse({
    title: 'React Fundamental',
    slug: 'react-fundamental',
    summary: 'State, props, effect, component design.',
    content:
      'Materi React:\n- JSX\n- Props/State\n- Lifecycle hooks\n- Best practice reusable component',
    level: 'Beginner',
    categoryId: web.id
  });

  await upsertCourse({
    title: 'OWASP Intro',
    slug: 'owasp-intro',
    summary: 'Pengenalan OWASP Top 10 pada aplikasi web.',
    content:
      'Bahas: Broken Access Control, Injection, Security Misconfiguration, dll.\nChecklist mitigasi disertakan.',
    level: 'Intermediate',
    categoryId: sec.id
  });

  await upsertCourse({
    title: 'Secure Authentication',
    slug: 'secure-authentication',
    summary: 'JWT, cookie strategy, password hashing, brute-force protection.',
    content:
      'Materi auth aman:\n- Argon2 hashing\n- HttpOnly cookie\n- Rate limiting\n- Role-based authorization',
    level: 'Intermediate',
    categoryId: sec.id
  });

  await upsertCourse({
    title: 'SQL for Data Pipeline',
    slug: 'sql-data-pipeline',
    summary: 'SQL penting untuk ETL/ELT.',
    content:
      'Materi SQL:\n- Join\n- Window Function\n- Aggregation\n- Incremental Load',
    level: 'Beginner',
    categoryId: data.id
  });

  await upsertCourse({
    title: 'Airflow Basic',
    slug: 'airflow-basic',
    summary: 'Orkestrasi workflow data dengan DAG.',
    content:
      'Materi Airflow:\n- DAG\n- Task dependency\n- Scheduler\n- Retry strategy',
    level: 'Intermediate',
    categoryId: data.id
  });

  await upsertCourse({
    title: 'Docker for Developer',
    slug: 'docker-for-developer',
    summary: 'Containerization untuk aplikasi modern.',
    content:
      'Materi Docker:\n- Image, container\n- Dockerfile\n- Compose\n- Multi-stage build',
    level: 'Beginner',
    categoryId: devops.id
  });

  await upsertCourse({
    title: 'CI/CD Basic',
    slug: 'ci-cd-basic',
    summary: 'Automasi build-test-deploy.',
    content:
      'Materi CI/CD:\n- Pipeline stages\n- Quality gate\n- Deployment strategy',
    level: 'Intermediate',
    categoryId: devops.id
  });

  await upsertCourse({
    title: 'Flutter Basic',
    slug: 'flutter-basic',
    summary: 'Mulai membuat aplikasi mobile cross-platform.',
    content:
      'Materi Flutter:\n- Widget tree\n- Navigation\n- State management basic',
    level: 'Beginner',
    categoryId: mobile.id
  });
}

main().finally(async () => prisma.$disconnect());
```

### `apps/web-app/app/courses/[slug]/page.tsx`
```tsx
import { Navbar } from '@/components/navbar';
import { api } from '@/lib/api';
import Link from 'next/link';

type Course = {
  id: string;
  title: string;
  slug: string;
  summary: string;
  content: string;
  level: string;
  category: { name: string; slug: string };
};

async function getCourses(): Promise<Course[]> {
  const res = await api.get('/courses');
  return res.data;
}

export default async function CourseDetailPage({ params }: { params: { slug: string } }) {
  const courses = await getCourses();
  const course = courses.find((c) => c.slug === params.slug);

  if (!course) {
    return (
      <>
        <Navbar />
        <main className="container" style={{ padding: '24px 0' }}>
          <div className="card">
            <h2>Kursus tidak ditemukan</h2>
            <Link href="/courses">Kembali ke daftar kursus</Link>
          </div>
        </main>
      </>
    );
  }

  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '24px 0' }}>
        <article className="card">
          <p style={{ color: 'var(--muted)', marginTop: 0 }}>
            {course.category.name} • {course.level}
          </p>
          <h1 style={{ marginTop: 6 }}>{course.title}</h1>
          <p>{course.summary}</p>
          <hr style={{ borderColor: '#243154' }} />
          <pre style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit' }}>{course.content}</pre>
        </article>
      </main>
    </>
  );
}
```

### `apps/web-app/app/courses/page.tsx` (replace with detail link)
```tsx
import { Navbar } from '@/components/navbar';
import { api } from '@/lib/api';
import Link from 'next/link';

type Course = {
  id: string;
  title: string;
  slug: string;
  summary: string;
  level: string;
  category: { name: string };
};

async function getCourses(): Promise<Course[]> {
  const res = await api.get('/courses');
  return res.data;
}

export default async function CoursesPage() {
  const courses = await getCourses();

  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '24px 0' }}>
        <h2>Kursus</h2>
        <div className="grid grid-3">
          {courses.map((c) => (
            <article key={c.id} className="card">
              <h3 style={{ marginTop: 0 }}>{c.title}</h3>
              <p style={{ color: 'var(--muted)' }}>{c.summary}</p>
              <p>Level: <strong>{c.level}</strong></p>
              <small>Kategori: {c.category.name}</small>
              <div style={{ marginTop: 12 }}>
                <Link href={`/courses/${c.slug}`} className="btn">Lihat Detail</Link>
              </div>
            </article>
          ))}
        </div>
      </main>
    </>
  );
}
```

### `apps/web-app/app/admin/page.tsx` (replace, add edit category/course)
```tsx
'use client';

import { Navbar } from '@/components/navbar';
import { api } from '@/lib/api';
import { useEffect, useState } from 'react';

type Me = { sub: string; email: string; role: 'USER' | 'ADMIN' };
type Category = { id: string; name: string; slug: string };
type Course = { id: string; title: string; slug: string; summary: string; content: string; level: string; categoryId: string };

export default function AdminPage() {
  const [me, setMe] = useState<Me | null>(null);
  const [msg, setMsg] = useState('Memeriksa sesi...');
  const [categories, setCategories] = useState<Category[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);

  const [catName, setCatName] = useState('');
  const [catSlug, setCatSlug] = useState('');
  const [editingCatId, setEditingCatId] = useState<string | null>(null);

  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [summary, setSummary] = useState('');
  const [content, setContent] = useState('');
  const [level, setLevel] = useState('Beginner');
  const [categoryId, setCategoryId] = useState('');
  const [editingCourseId, setEditingCourseId] = useState<string | null>(null);

  async function loadAll() {
    const [catRes, courseRes] = await Promise.all([api.get('/categories'), api.get('/courses')]);
    setCategories(catRes.data);
    setCourses(courseRes.data);
    if (catRes.data?.length && !categoryId) setCategoryId(catRes.data[0].id);
  }

  useEffect(() => {
    api.get('/auth/me')
      .then(async (res) => {
        const data = res.data as Me;
        setMe(data);
        if (data.role !== 'ADMIN') setMsg('Akun ini bukan admin');
        else {
          setMsg('Akses admin diberikan');
          await loadAll();
        }
      })
      .catch(() => setMsg('Belum login'));
  }, []);

  function resetCategoryForm() {
    setCatName('');
    setCatSlug('');
    setEditingCatId(null);
  }

  async function submitCategory(e: React.FormEvent) {
    e.preventDefault();
    if (!editingCatId) await api.post('/categories', { name: catName, slug: catSlug });
    else await api.patch(`/categories/${editingCatId}`, { name: catName, slug: catSlug });
    resetCategoryForm();
    await loadAll();
  }

  function startEditCategory(c: Category) {
    setEditingCatId(c.id);
    setCatName(c.name);
    setCatSlug(c.slug);
  }

  async function deleteCategory(id: string) {
    await api.delete(`/categories/${id}`);
    await loadAll();
  }

  function resetCourseForm() {
    setTitle('');
    setSlug('');
    setSummary('');
    setContent('');
    setLevel('Beginner');
    setEditingCourseId(null);
  }

  async function submitCourse(e: React.FormEvent) {
    e.preventDefault();
    const payload = { title, slug, summary, content, level, categoryId };
    if (!editingCourseId) await api.post('/courses', payload);
    else await api.patch(`/courses/${editingCourseId}`, payload);
    resetCourseForm();
    await loadAll();
  }

  function startEditCourse(c: Course) {
    setEditingCourseId(c.id);
    setTitle(c.title);
    setSlug(c.slug);
    setSummary(c.summary);
    setContent(c.content);
    setLevel(c.level);
    setCategoryId(c.categoryId);
  }

  async function deleteCourse(id: string) {
    await api.delete(`/courses/${id}`);
    await loadAll();
  }

  async function logout() {
    await api.post('/auth/logout');
    setMe(null);
    setMsg('Logout berhasil');
  }

  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '24px 0', display: 'grid', gap: 16 }}>
        <div className="card">
          <h2>Admin Panel</h2>
          <p>{msg}</p>
          {me && <p>{me.email} ({me.role})</p>}
          {me && <button className="btn" onClick={logout}>Logout</button>}
        </div>

        <div className="card">
          <h3>{editingCatId ? 'Edit Kategori' : 'Tambah Kategori'}</h3>
          <form onSubmit={submitCategory} className="grid">
            <input className="input" placeholder="Nama kategori" value={catName} onChange={(e) => setCatName(e.target.value)} />
            <input className="input" placeholder="Slug kategori" value={catSlug} onChange={(e) => setCatSlug(e.target.value)} />
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn">{editingCatId ? 'Update' : 'Simpan'}</button>
              {editingCatId && <button type="button" className="btn" onClick={resetCategoryForm} style={{ background: '#64748b' }}>Batal</button>}
            </div>
          </form>

          <div style={{ marginTop: 12, display: 'grid', gap: 8 }}>
            {categories.map((c) => (
              <div key={c.id} className="card" style={{ padding: 10 }}>
                <strong>{c.name}</strong> <small style={{ color: 'var(--muted)' }}>({c.slug})</small>
                <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
                  <button className="btn" onClick={() => startEditCategory(c)} style={{ background: '#0ea5e9' }}>Edit</button>
                  <button className="btn" onClick={() => deleteCategory(c.id)} style={{ background: 'var(--danger)' }}>Hapus</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <h3>{editingCourseId ? 'Edit Kursus' : 'Tambah Kursus'}</h3>
          <form onSubmit={submitCourse} className="grid">
            <input className="input" placeholder="Judul" value={title} onChange={(e) => setTitle(e.target.value)} />
            <input className="input" placeholder="Slug" value={slug} onChange={(e) => setSlug(e.target.value)} />
            <input className="input" placeholder="Ringkasan" value={summary} onChange={(e) => setSummary(e.target.value)} />
            <textarea className="input" placeholder="Konten" value={content} onChange={(e) => setContent(e.target.value)} rows={6} />
            <select className="input" value={level} onChange={(e) => setLevel(e.target.value)}>
              <option>Beginner</option>
              <option>Intermediate</option>
              <option>Advanced</option>
            </select>
            <select className="input" value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}

## User

next

## Assistant

Lanjut bagian akhir file `apps/web-app/app/admin/page.tsx` yang kepotong:

```tsx
            </select>

            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn">{editingCourseId ? 'Update' : 'Simpan'}</button>
              {editingCourseId && (
                <button
                  type="button"
                  className="btn"
                  onClick={resetCourseForm}
                  style={{ background: '#64748b' }}
                >
                  Batal
                </button>
              )}
            </div>
          </form>

          <div style={{ marginTop: 12, display: 'grid', gap: 8 }}>
            {courses.map((c) => (
              <div key={c.id} className="card" style={{ padding: 10 }}>
                <strong>{c.title}</strong>{' '}
                <small style={{ color: 'var(--muted)' }}>
                  ({c.slug}) - {c.level}
                </small>
                <div style={{ marginTop: 8, display: 'flex', gap: 8 }}>
                  <button
                    className="btn"
                    onClick={() => startEditCourse(c)}
                    style={{ background: '#0ea5e9' }}
                  >
                    Edit
                  </button>
                  <button
                    className="btn"
                    onClick={() => deleteCourse(c.id)}
                    style={{ background: 'var(--danger)' }}
                  >
                    Hapus
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </>
  );
}
```

---

## File tambahan terakhir (opsional tapi disarankan)

### `apps/api-server/src/modules/health/health.controller.ts`
```ts
import { Controller, Get } from '@nestjs/common';

@Controller('health')
export class HealthController {
  @Get()
  check() {
    return { ok: true, service: 'api-server', time: new Date().toISOString() };
  }
}
```

### `apps/api-server/src/modules/health/health.module.ts`
```ts
import { Module } from '@nestjs/common';
import { HealthController } from './health.controller';

@Module({
  controllers: [HealthController]
})
export class HealthModule {}
```

### `apps/api-server/src/modules/app.module.ts` (update import HealthModule)
```ts
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { CategoriesModule } from './categories/categories.module';
import { CoursesModule } from './courses/courses.module';
import { HealthModule } from './health/health.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    ThrottlerModule.forRoot([{ ttl: 60, limit: 30 }]),
    PrismaModule,
    AuthModule,
    UsersModule,
    CategoriesModule,
    CoursesModule,
    HealthModule
  ]
})
export class AppModule {}
```

---

## Perintah run final

```bash
npm i -g pnpm
pnpm install

cp apps/api-server/.env.example apps/api-server/.env
cp apps/web-app/.env.example apps/web-app/.env

pnpm --filter api-server prisma generate
pnpm --filter api-server prisma migrate dev --name init
pnpm --filter api-server prisma db seed

pnpm dev
```

Cek:
- Web: `http://localhost:3000`
- API: `http://localhost:4000/health`

---

Kalau mau, saya lanjut **1 pesan terakhir** berisi:
- **checklist anti-kelupaan** (semua file yang wajib ada),
- cara **export ZIP dari HP (Replit) step-by-step sangat singkat**.

## User

ok next

## Assistant

Mantap. Ini **checklist final anti-kelupaan** + **cara export ZIP via HP**.

## ✅ Checklist Wajib

### Root
- `package.json`
- `pnpm-workspace.yaml`
- `.gitignore`
- `README.md`
- `docker-compose.yml` (opsional)

### Backend `apps/api-server`
- `package.json`
- `.env` (copy dari `.env.example`)
- `tsconfig.json`
- `nest-cli.json`
- `prisma/schema.prisma`
- `prisma/seed.ts`
- `src/main.ts`
- `src/modules/app.module.ts`
- `src/modules/prisma/*`
- `src/modules/auth/*`
- `src/modules/users/*`
- `src/modules/categories/*` (+ dto)
- `src/modules/courses/*` (+ dto)
- `src/modules/common/guards/admin.guard.ts`
- `src/modules/health/*`
- `Dockerfile` (opsional)

### Frontend `apps/web-app`
- `package.json`
- `.env` (copy dari `.env.example`)
- `next.config.mjs`
- `tsconfig.json`
- `next-env.d.ts`
- `middleware.ts`
- `app/globals.css`
- `app/layout.tsx`
- `app/page.tsx`
- `app/categories/page.tsx`
- `app/courses/page.tsx`
- `app/courses/[slug]/page.tsx`
- `app/login/page.tsx`
- `app/admin/page.tsx`
- `components/navbar.tsx`
- `lib/api.ts`
- `Dockerfile` (opsional)

### Shared UI `packages/ui`
- `package.json`
- `src/button.tsx`
- `src/index.ts`

---

## ✅ Urutan Jalanin (harus urut)

```bash
npm i -g pnpm
pnpm install
cp apps/api-server/.env.example apps/api-server/.env
cp apps/web-app/.env.example apps/web-app/.env
pnpm --filter api-server prisma generate
pnpm --filter api-server prisma migrate dev --name init
pnpm --filter api-server prisma db seed
pnpm dev
```

Login admin:
- email: `admin@techstudyspace.com`
- password: `Admin1234`

---

## 📦 Export ZIP dari HP (Replit)

1. Buka project Replit Anda.
2. Pastikan semua file sudah ada.
3. Klik menu titik tiga `⋮` pada Files / Project.
4. Pilih **Download as ZIP**.
5. Tunggu selesai, file `.zip` masuk ke HP.

---

Kalau Anda mau, saya bisa kirim **“struktur pohon final 1 blok”** (siap Anda cocokkan cepat baris per baris).

## User

next

## Assistant

```txt
tech-study-space/
├─ .gitignore
├─ README.md
├─ package.json
├─ pnpm-workspace.yaml
├─ docker-compose.yml
├─ apps/
│  ├─ api-server/
│  │  ├─ .env.example
│  │  ├─ package.json
│  │  ├─ tsconfig.json
│  │  ├─ nest-cli.json
│  │  ├─ Dockerfile
│  │  ├─ prisma/
│  │  │  ├─ schema.prisma
│  │  │  └─ seed.ts
│  │  └─ src/
│  │     ├─ main.ts
│  │     └─ modules/
│  │        ├─ app.module.ts
│  │        ├─ prisma/
│  │        │  ├─ prisma.module.ts
│  │        │  └─ prisma.service.ts
│  │        ├─ health/
│  │        │  ├─ health.module.ts
│  │        │  └─ health.controller.ts
│  │        ├─ common/
│  │        │  └─ guards/
│  │        │     └─ admin.guard.ts
│  │        ├─ auth/
│  │        │  ├─ auth.module.ts
│  │        │  ├─ auth.service.ts
│  │        │  ├─ auth.controller.ts
│  │        │  ├─ jwt.strategy.ts
│  │        │  ├─ jwt-auth.guard.ts
│  │        │  ├─ roles.guard.ts
│  │        │  └─ dto/
│  │        │     └─ login.dto.ts
│  │        ├─ users/
│  │        │  ├─ users.module.ts
│  │        │  └─ users.service.ts
│  │        ├─ categories/
│  │        │  ├─ categories.module.ts
│  │        │  ├─ categories.service.ts
│  │        │  ├─ categories.controller.ts
│  │        │  └─ dto/
│  │        │     ├─ create-category.dto.ts
│  │        │     └─ update-category.dto.ts
│  │        └─ courses/
│  │           ├─ courses.module.ts
│  │           ├─ courses.service.ts
│  │           ├─ courses.controller.ts
│  │           └─ dto/
│  │              ├─ create-course.dto.ts
│  │              └─ update-course.dto.ts
│  └─ web-app/
│     ├─ .env.example
│     ├─ package.json
│     ├─ tsconfig.json
│     ├─ next.config.mjs
│     ├─ next-env.d.ts
│     ├─ middleware.ts
│     ├─ Dockerfile
│     ├─ lib/
│     │  └─ api.ts
│     ├─ components/
│     │  └─ navbar.tsx
│     └─ app/
│        ├─ globals.css
│        ├─ layout.tsx
│        ├─ page.tsx
│        ├─ login/
│        │  └─ page.tsx
│        ├─ admin/
│        │  └─ page.tsx
│        ├─ categories/
│        │  └─ page.tsx
│        └─ courses/
│           ├─ page.tsx
│           └─ [slug]/
│              └─ page.tsx
└─ packages/
   └─ ui/
      ├─ package.json
      └─ src/
         ├─ button.tsx
         └─ index.ts
```

Siap. Kalau Anda mau, saya lanjut **verifikasi cepat**:  
Anda kirim screenshot/error terminal, saya bantu bereskan sampai `pnpm dev` sukses.