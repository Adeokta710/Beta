# Kubernetes scale-up blueprint
Use only when traffic/team boundaries justify it. Include separate web/api deployments, services, ingress, config/secret management, HPA, PodDisruptionBudget and monitoring. Never commit real secrets.
