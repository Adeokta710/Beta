/// <reference types="next" />
/// <reference types="next/image-types/global" />

// NOTE: file ini auto-generated oleh Next.js
