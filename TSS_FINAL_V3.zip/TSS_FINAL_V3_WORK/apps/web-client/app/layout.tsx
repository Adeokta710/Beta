import './globals.css'; import type {Metadata} from 'next';
export const metadata:Metadata={title:'Technology Study Surabaya — TSS',description:'Platform pembelajaran teknologi TSS'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="id"><body><div className="main-content">{children}<footer className="container" style={{padding:'40px 0',color:'var(--muted)'}}>© Technology Study Surabaya (TSS) • Ayo Arek-Arek Suroboyo, Belajar Teknologi mulai Saiki</footer></div></body></html>}
