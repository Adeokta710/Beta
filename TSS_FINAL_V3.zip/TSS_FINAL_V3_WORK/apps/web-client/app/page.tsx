import { Navbar } from '@/components/navbar';

export default function HomePage() {
  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '28px 0' }}>
        <section className="card">
          <h1 style={{ marginTop: 0 }}>Belajar Teknologi Lebih Terstruktur</h1>
          <p style={{ color: 'var(--muted)' }}>
            Jelajahi kategori, ikuti kursus, dan tingkatkan skill Anda di Tech Study Space.
          </p>
        </section>
      </main>
    </>
  );
}
