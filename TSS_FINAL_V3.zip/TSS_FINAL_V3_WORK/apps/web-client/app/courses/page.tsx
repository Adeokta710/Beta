export const dynamic = "force-dynamic";
export const dynamic = 'force-dynamic';
import { Navbar } from '@/components/navbar';
import { api } from '@/lib/api';
import Link from 'next/link';

type Course = {
  id: string;
  title: string;
  slug: string;
  summary: string;
  level: string;
  category: { name: string };
};

async function getCourses(): Promise<Course[]> {
  const res = await api.get('/courses');
  return res.data;
}

export default async function CoursesPage() {
  const courses = await getCourses();

  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '24px 0' }}>
        <h2>Kursus</h2>
        <div className="grid grid-3">
          {courses.map((c) => (
            <article key={c.id} className="card">
              <h3 style={{ marginTop: 0 }}>{c.title}</h3>
              <p style={{ color: 'var(--muted)' }}>{c.summary}</p>
              <p>Level: <strong>{c.level}</strong></p>
              <small>Kategori: {c.category.name}</small>
              <div style={{ marginTop: 12 }}>
                <Link href={`/courses/${c.slug}`} className="btn">Lihat Detail</Link>
              </div>
            </article>
          ))}
        </div>
      </main>
    </>
  );
}
