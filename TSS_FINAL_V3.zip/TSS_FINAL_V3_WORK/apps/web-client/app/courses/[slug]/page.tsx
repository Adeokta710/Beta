export const dynamic = "force-dynamic";
export const dynamic = 'force-dynamic';
import { Navbar } from '@/components/navbar';
import { api } from '@/lib/api';
import Link from 'next/link';

type Course = {
  id: string;
  title: string;
  slug: string;
  summary: string;
  content: string;
  level: string;
  category: { name: string; slug: string };
};

async function getCourses(): Promise<Course[]> {
  const res = await api.get('/courses');
  return res.data;
}

export default async function CourseDetailPage({ params }: { params: { slug: string } }) {
  const courses = await getCourses();
  const course = courses.find((c) => c.slug === params.slug);

  if (!course) {
    return (
      <>
        <Navbar />
        <main className="container" style={{ padding: '24px 0' }}>
          <div className="card">
            <h2>Kursus tidak ditemukan</h2>
            <Link href="/courses">Kembali ke daftar kursus</Link>
          </div>
        </main>
      </>
    );
  }

  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '24px 0' }}>
        <article className="card">
          <p style={{ color: 'var(--muted)', marginTop: 0 }}>
            {course.category.name} • {course.level}
          </p>
          <h1 style={{ marginTop: 6 }}>{course.title}</h1>
          <p>{course.summary}</p>
          <hr style={{ borderColor: '#243154' }} />
          <pre style={{ whiteSpace: 'pre-wrap', fontFamily: 'inherit' }}>{course.content}</pre>
        </article>
      </main>
    </>
  );
}
