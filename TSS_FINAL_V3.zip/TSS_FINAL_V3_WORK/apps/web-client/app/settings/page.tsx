'use client';
import {Navbar} from '@/components/navbar'; import {useState} from 'react';
export default function Settings(){const[reduced,setReduced]=useState(false);return <><Navbar/><main className="container" style={{padding:'24px 0'}}><section className="card"><h1>Settings</h1><label><input type="checkbox" checked={reduced} onChange={e=>setReduced(e.target.checked)}/> Reduced motion</label><p className="muted">Preferensi lokal UI. Preferensi akun dapat dikembangkan melalui API settings.</p></section></main></>}
