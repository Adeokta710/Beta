export const dynamic = "force-dynamic";
import {Navbar} from '@/components/navbar'; import {api} from '@/lib/api';
export default async function TutorialDetail({params}:{params:{slug:string}}){const r=await api.get(`/tutorials/${params.slug}`);const x=r.data;return <><Navbar/><main className="container" style={{padding:'24px 0'}}><article className="card"><p className="pill">Tutorial</p><h1>{x.title}</h1><p className="muted">{x.summary}</p><pre style={{whiteSpace:'pre-wrap',fontFamily:'inherit'}}>{x.content}</pre></article></main></>}
