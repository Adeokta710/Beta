export const dynamic = "force-dynamic";
export const dynamic = 'force-dynamic';
import { Navbar } from '@/components/navbar';
import { api } from '@/lib/api';

type Category = {
  id: string;
  name: string;
  slug: string;
  courses: { id: string; title: string }[];
};

async function getCategories(): Promise<Category[]> {
  const res = await api.get('/categories');
  return res.data;
}

export default async function CategoriesPage() {
  const categories = await getCategories();

  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '24px 0' }}>
        <h2>Kategori</h2>
        <div className="grid grid-3">
          {categories.map((c) => (
            <article key={c.id} className="card">
              <h3 style={{ marginTop: 0 }}>{c.name}</h3>
              <p style={{ color: 'var(--muted)' }}>Slug: {c.slug}</p>
              <small>{c.courses.length} kursus</small>
            </article>
          ))}
        </div>
      </main>
    </>
  );
}
