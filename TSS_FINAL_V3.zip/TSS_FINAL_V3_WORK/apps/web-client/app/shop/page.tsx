export const dynamic = "force-dynamic";
import {Navbar} from '@/components/navbar'; import {api} from '@/lib/api';
export default async function Shop(){const r=await api.get('/shop/products');const items=r.data;return <><Navbar/><main className="container" style={{padding:'24px 0'}}><h1>Shop</h1><div className="grid grid-3">{items.map((x:any)=><article className="card" key={x.id}><h3>{x.name}</h3><p className="muted">{x.description}</p><strong>Rp {x.price.toLocaleString('id-ID')}</strong><p>Stok: {x.stock}</p></article>)}</div></main></>}
