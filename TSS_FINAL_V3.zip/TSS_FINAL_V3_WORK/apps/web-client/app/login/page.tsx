'use client';

import { Navbar } from '@/components/navbar';
import { api } from '@/lib/api';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('admin@tss.local');
  const [password, setPassword] = useState('Admin1234');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMsg('');
    try {
      await api.post('/auth/login', { email, password });
      setMsg('Login berhasil');
      router.push('/admin');
    } catch (e: any) {
      setMsg(e?.response?.data?.message || 'Login gagal');
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Navbar />
      <main className="container" style={{ padding: '24px 0' }}>
        <div className="card" style={{ maxWidth: 460 }}>
          <h2>Login</h2>
          <form onSubmit={onSubmit} className="grid">
            <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
            <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
            <button className="btn" disabled={loading}>{loading ? 'Loading...' : 'Masuk'}</button>
          </form>
          {msg && <p style={{ marginTop: 10 }}>{msg}</p>}
        </div>
      </main>
    </>
  );
}
