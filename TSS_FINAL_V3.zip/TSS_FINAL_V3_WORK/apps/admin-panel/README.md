# TSS Admin Panel
Separate admin boundary. Production may use the same design system/API with stricter RBAC.
