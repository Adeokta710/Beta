import './globals.css'; export const metadata={title:'TSS Admin'}; export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="id"><body>{children}</body></html>}
