import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const apiRoot=path.resolve(new URL('.',import.meta.url).pathname,'..'); const projectRoot=path.resolve(apiRoot,'..','..');
test('Prisma uses PostgreSQL',()=>{const s=fs.readFileSync(path.join(apiRoot,'prisma/schema.prisma'),'utf8');assert.match(s,/provider\s*=\s*"postgresql"/);assert.doesNotMatch(s,/provider\s*=\s*"sqlite"/)});
test('legacy placeholders are absent from app source',()=>{const dirs=[path.join(apiRoot,'src'),path.join(projectRoot,'apps','web-client','app')];for(const d of dirs)walk(d,f=>{if(/\.(ts|tsx)$/.test(f)){const s=fs.readFileSync(f,'utf8');assert.doesNotMatch(s,/## User|## Assistant/);assert.doesNotMatch(s,/status\s*:\s*['"]ready['"]/);}})});
function walk(dir,fn){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const f=path.join(dir,e.name);if(e.isDirectory())walk(f,fn);else fn(f)}}
test('tool calculations are mathematically consistent',()=>{assert.equal(12/1000,0.012);assert.equal(12*2/(1000+1000),0.012)});
