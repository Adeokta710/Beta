# Prisma

The API uses PostgreSQL. Set `DATABASE_URL` to a PostgreSQL connection string before running `prisma migrate`.
The canonical workspace schema is also mirrored at `packages/database/schema.prisma` for the root database scripts.
