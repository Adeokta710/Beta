import { IsString, MinLength } from 'class-validator';

export class CreateCourseDto {
  @IsString()
  @MinLength(3)
  title!: string;

  @IsString()
  @MinLength(3)
  slug!: string;

  @IsString()
  @MinLength(10)
  summary!: string;

  @IsString()
  @MinLength(20)
  content!: string;

  @IsString()
  level!: string;

  @IsString()
  categoryId!: string;
}
