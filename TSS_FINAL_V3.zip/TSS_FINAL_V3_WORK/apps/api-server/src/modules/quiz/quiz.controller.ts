import {Body,Controller,Get,Param,Post,Req,UseGuards} from '@nestjs/common';
import {PrismaService} from '../prisma/prisma.service';
import {JwtAuthGuard} from '../auth/jwt-auth.guard';
@Controller('quiz')
export class QuizController {
  constructor(private p:PrismaService){}
  @Get() all(){return this.p.quiz.findMany({include:{questions:{select:{id:true,prompt:true,options:true}}}});}
  @Get(':id') one(@Param('id')id:string){return this.p.quiz.findUnique({where:{id},include:{questions:{select:{id:true,prompt:true,options:true}}}});}
  @Post(':id/attempt') @UseGuards(JwtAuthGuard)
  async attempt(@Param('id')id:string,@Req()r:any,@Body()d:any){
    const q=await this.p.quiz.findUnique({where:{id},include:{questions:true}}); if(!q)return{error:'Quiz tidak ditemukan'};
    let score=0; for(const x of q.questions){if(d.answers?.[x.id]===x.answer)score++;}
    const total=q.questions.length;
    return this.p.quizAttempt.create({data:{userId:r.user.sub,quizId:id,score:total?Math.round(score/total*100):0,answers:d.answers||{}}});
  }
}
