import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { APP_GUARD } from '@nestjs/core';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { CategoriesModule } from './categories/categories.module';
import { CoursesModule } from './courses/courses.module';
import { HealthModule } from './health/health.module';
import { LearningModule } from './learning/learning.module';
import { TutorialsModule } from './tutorials/tutorials.module';
import { ProblemsModule } from './problems/problems.module';
import { QuizModule } from './quiz/quiz.module';
import { ToolsModule } from './tools/tools.module';
import { SearchModule } from './search/search.module';
import { ProgressModule } from './progress/progress.module';
import { BookmarksModule } from './bookmarks/bookmarks.module';
import { AuditModule } from './audit/audit.module';
import { NotificationsModule } from './notifications/notifications.module';
import { MediaModule } from './media/media.module';
import { ShopModule } from './shop/shop.module';
import { AdminModule } from './admin/admin.module';
@Module({imports:[ConfigModule.forRoot({isGlobal:true}),ThrottlerModule.forRoot([{ttl:60000,limit:60}]),PrismaModule,AuthModule,UsersModule,CategoriesModule,CoursesModule,HealthModule,LearningModule,TutorialsModule,ProblemsModule,QuizModule,ToolsModule,SearchModule,ProgressModule,BookmarksModule,AuditModule,NotificationsModule,MediaModule,ShopModule,AdminModule],providers:[{provide:APP_GUARD,useClass:ThrottlerGuard}]})
export class AppModule {}
