import { Body, Controller, Get, Post, Req, Res, UseGuards } from '@nestjs/common';
import { Response } from 'express';
import { IsEmail, IsString, MinLength } from 'class-validator';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './jwt-auth.guard';
class AuthDto { @IsEmail() email!: string; @IsString() @MinLength(6) password!: string; }
class RegisterDto extends AuthDto { @IsString() @MinLength(2) name!: string; }
@Controller('auth')
export class AuthController {
 constructor(private auth: AuthService) {}
 private setCookies(res: Response, r:any) { res.cookie('access_token',r.accessToken,{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:86400000}); res.cookie('refresh_token',r.refreshToken,{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:30*86400000}); }
 @Post('register') async register(@Body() dto:RegisterDto,@Res({passthrough:true})res:Response){const r=await this.auth.register(dto.email,dto.password,dto.name);this.setCookies(res,r);return r.user;}
 @Post('login') async login(@Body() dto:AuthDto,@Res({passthrough:true})res:Response){const r=await this.auth.login(dto.email,dto.password);this.setCookies(res,r);return r.user;}
 @Post('refresh') async refresh(@Req() req:any,@Res({passthrough:true})res:Response){const r=await this.auth.refresh(req.cookies?.refresh_token||'');this.setCookies(res,r);return r.user;}
 @Post('logout') async logout(@Req() req:any,@Res({passthrough:true})res:Response){await this.auth.logout(req.cookies?.refresh_token);res.clearCookie('access_token');res.clearCookie('refresh_token');return {ok:true};}
 @UseGuards(JwtAuthGuard) @Get('me') me(@Req()req:any){return req.user;}
}
