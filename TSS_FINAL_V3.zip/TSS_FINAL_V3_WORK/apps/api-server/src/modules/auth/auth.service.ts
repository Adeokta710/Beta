import { Injectable, UnauthorizedException, ConflictException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as argon2 from 'argon2';
import { randomBytes } from 'crypto';
import { UsersService } from '../users/users.service';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AuthService {
  constructor(private users: UsersService, private jwt: JwtService, private prisma: PrismaService) {}
  async register(email:string,password:string,name:string){
    if(await this.users.findByEmail(email)) throw new ConflictException('Email already registered');
    const user=await this.users.create({email:email.toLowerCase().trim(),passwordHash:await argon2.hash(password),name:name.trim()});
    return this.issue(user);
  }
  async login(email:string,password:string){
    const user=await this.users.findByEmail(email.toLowerCase().trim());
    if(!user || !(await argon2.verify(user.passwordHash,password))) throw new UnauthorizedException('Invalid credentials');
    return this.issue(user);
  }
  private async issue(user:any){
    const accessToken=await this.jwt.signAsync({sub:user.id,email:user.email,role:user.role});
    const secret=randomBytes(48).toString('hex');
    const session=await this.prisma.session.create({data:{userId:user.id,refreshTokenHash:await argon2.hash(secret),expiresAt:new Date(Date.now()+30*86400000)}});
    return {accessToken,refreshToken:`${session.id}.${secret}`,user:{id:user.id,email:user.email,name:user.name,role:user.role}};
  }
  async refresh(token:string){
    const [sessionId,secret]=token.split('.');
    if(!sessionId||!secret) throw new UnauthorizedException('Invalid refresh token');
    const session=await this.prisma.session.findUnique({where:{id:sessionId}});
    if(!session || session.revokedAt || session.expiresAt<=new Date() || !(await argon2.verify(session.refreshTokenHash,secret))) throw new UnauthorizedException('Invalid refresh token');
    await this.prisma.session.update({where:{id:session.id},data:{revokedAt:new Date()}});
    const user=await this.users.findById(session.userId);
    if(!user) throw new UnauthorizedException('User not found');
    return this.issue(user);
  }
  async logout(token?:string){
    if(!token) return; const [id]=token.split('.'); if(id) await this.prisma.session.updateMany({where:{id},data:{revokedAt:new Date()}});
  }
}
