import 'reflect-metadata';
import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import { AppModule } from './modules/app.module';
async function bootstrap(){const app=await NestFactory.create(AppModule);app.setGlobalPrefix('api/v1');app.use(cookieParser());app.use(helmet());const origins=(process.env.FRONTEND_URL||'http://localhost:3000').split(',').map(x=>x.trim());app.enableCors({origin:(origin,cb)=>{if(!origin||origins.includes(origin))return cb(null,true);return cb(new Error('CORS origin denied'),false)},credentials:true});app.useGlobalPipes(new ValidationPipe({whitelist:true,transform:true,forbidNonWhitelisted:true}));await app.listen(Number(process.env.PORT)||4000);}
bootstrap();
