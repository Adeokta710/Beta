# TSS UI System
Accessible components, tokens, dark/sky-blue visual language, responsive states and reduced-motion guidance.
