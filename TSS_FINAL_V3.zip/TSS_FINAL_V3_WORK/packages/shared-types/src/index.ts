export type Role = 'USER' | 'INSTRUCTOR' | 'ADMIN' | 'SUPERADMIN';
export type ContentStatus = 'DRAFT' | 'REVIEW' | 'PUBLISHED' | 'ARCHIVED';
export type ContentType = 'MATERIAL' | 'TUTORIAL' | 'PROBLEM' | 'QUIZ' | 'TOOL';
export interface Page<T> { data: T[]; nextCursor?: string | null; total?: number; }
export interface ApiError { statusCode: number; code: string; message: string; requestId?: string; }
