import * as React from 'react';

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  children: React.ReactNode;
};

export function UIButton({ children, ...props }: Props) {
  return (
    <button
      {...props}
      style={{
        background: '#5b8cff',
        color: '#fff',
        border: 0,
        borderRadius: 10,
        padding: '10px 14px',
        cursor: 'pointer'
      }}
    >
      {children}
    </button>
  );
}
