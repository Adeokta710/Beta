# Admin/CMS Final

Workflow: Draft → Review → Publish → Archive.

Editor: title, slug, excerpt, category, tags, level, duration, hero, body blocks, SEO, canonical, author, reviewer, status, publishedAt.

Features: autosave, preview, revision history, optimistic concurrency, media validation, audit log, role checks.


---
## V3 Addendum
V3 is the authoritative implementation baseline. Earlier V1/V2 statements in this document are retained as historical design context; when they conflict with V3 code/configuration, V3 implementation and `docs/18-FINAL-AUDIT-V3.md` take precedence.
