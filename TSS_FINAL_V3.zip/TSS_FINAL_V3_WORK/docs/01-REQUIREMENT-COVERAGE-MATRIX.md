# Requirement Coverage Matrix

| Requirement | Design | Code baseline | Status/verification |
|---|---|---|---|
| TSS identity/tagline | Yes | README/docs | Covered |
| Header/sidebar/footer | Yes | web-client | Baseline |
| Mobile drawer | Yes | web-client | Baseline |
| Original menu/taxonomy | Yes | seed/docs | Covered as taxonomy |
| Deep content taxonomy | Yes | docs/seed | Expandable |
| Materials/tutorials/problems/tools | Yes | API modules/models | Baseline |
| Progress/bookmarks | Yes | API contract/models | Baseline |
| Admin/CMS | Yes | admin boundary/API | Baseline |
| Auth/RBAC | Yes | API auth | Baseline |
| Refresh/session revocation | Yes | schema/design | Requires runtime test |
| Redis rate limiting | Yes | infra/design | Requires runtime test |
| Security headers/CORS | Yes | API | Baseline |
| PostgreSQL/Prisma | Yes | schema | Baseline |
| Docker/NGINX | Yes | infra | Baseline |
| CI | Yes | workflow | Baseline |
| E2E | Yes | test plan | Must execute |
| Full content library | Requirement only | seed catalog | Not claimed complete |
| Production deployment | Design | infra | Environment-dependent |

A “Baseline” means files and interfaces are present; it does not mean production runtime verification has been performed in this environment.


---
## V3 Addendum
V3 is the authoritative implementation baseline. Earlier V1/V2 statements in this document are retained as historical design context; when they conflict with V3 code/configuration, V3 implementation and `docs/18-FINAL-AUDIT-V3.md` take precedence.
