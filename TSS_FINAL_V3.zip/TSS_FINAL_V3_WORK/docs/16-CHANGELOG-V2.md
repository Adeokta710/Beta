# Final V2 Changes

- Combined latest supplied Markdown prompt, original TSS conversation and prior v1 blueprint.
- Canonicalized public app name to `web-client`; retained legacy `web-app` mapping.
- Preserved original TSS menu/taxonomy.
- Added deep subject/content requirements including Resistor.
- Separated navigation, taxonomy and content.
- Kept modular monolith as initial backend.
- Hardened auth/session/security model.
- Added CMS workflow/revisions/audit.
- Added requirement coverage matrix.
- Preserved source documents for traceability.
- Explicitly separated baseline code from runtime-verified status.
