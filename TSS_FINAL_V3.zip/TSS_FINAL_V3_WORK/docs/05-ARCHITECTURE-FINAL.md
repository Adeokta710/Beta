# Architecture Final

```text
Internet
  |
NGINX
  |
+----------------------+--------------------+
|                                           |
Next.js web-client                     NestJS api-server
                                             |
                                  +----------+----------+
                                  |                     |
                              PostgreSQL              Redis
                                  |
                           Object/media storage
```

Monorepo: `apps/web-client`, `apps/api-server`, `apps/admin-panel`, `packages/database`, `packages/shared-types`, `packages/ui-system`.

Backend modules: auth, users, categories, learning/materials, tutorials, problems, quiz, tools, search, bookmarks, progress, notifications, media, shop, admin, audit, health.

Initial architecture is a modular monolith. Split services only after measurable scaling/team requirements.


---
## V3 Addendum
V3 is the authoritative implementation baseline. Earlier V1/V2 statements in this document are retained as historical design context; when they conflict with V3 code/configuration, V3 implementation and `docs/18-FINAL-AUDIT-V3.md` take precedence.
