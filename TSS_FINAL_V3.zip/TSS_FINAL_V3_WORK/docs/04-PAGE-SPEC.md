# Page Specification

Public: `/`, `/belajar`, `/belajar/[category]`, `/materi`, `/materi/[slug]`, `/tutorial`, `/tutorial/[slug]`, `/problem-solved`, `/problem-solved/[slug]`, `/tools`, `/search`.

Account: `/login`, `/register`, `/profile`, `/progress`, `/bookmark`, `/history`, `/settings`.

Admin: `/admin`, `/admin/content`, `/admin/categories`, `/admin/users`, `/admin/media`, `/admin/audit`, `/admin/settings`.

Learning detail pages support breadcrumbs, title, metadata, TOC, content blocks, code, diagrams/images, related material/tutorial/problem, bookmark, progress and feedback.
