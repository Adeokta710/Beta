# Deployment Final

Local: Docker Compose PostgreSQL/Redis.
Production baseline: NGINX + web + API + PostgreSQL + Redis.
Observability: health/ready endpoints, structured logs, Prometheus metrics; Grafana optional.
Scale-up: Kubernetes with separate web/API deployments, ingress, config/secret management, HPA, monitoring.

Secrets are injected, never committed. Database migrations run as a controlled release step.


---
## V3 Addendum
V3 is the authoritative implementation baseline. Earlier V1/V2 statements in this document are retained as historical design context; when they conflict with V3 code/configuration, V3 implementation and `docs/18-FINAL-AUDIT-V3.md` take precedence.
