# TSS FINAL V2 — Master Requirements

## Product identity
Technology Study Surabaya (TSS), tagline: “Ayo Arek-Arek Suroboyo, Belajar Teknologi mulai Saiki”. TSS is a technology learning platform for students, vocational students, university students, technicians, programmers, and the public.

## Must preserve
- Original TSS identity and learning-platform positioning.
- Header + Sidebar + Main Content + Footer.
- Mobile drawer/navigation.
- Navigation chain: menu → dropdown → submenu → category → material.
- Material, Tutorial, Problem Solved, Tools, Technology, repair/technical troubleshooting, Progress, Bookmark, Profile, Admin, Shop module boundary.
- Original learning domains and category tree.

## UI direction
Modern, minimal, technology-focused, professional, dark-first, responsive/mobile-friendly. Primary palette: dark blue, sky blue, white, black. Include accessible contrast, focus states, reduced motion, skeleton/loading, error states, empty states, hover/active states, responsive drawer, typography, borders, cards, backgrounds and animation.

## Content requirement
The platform must support learning from basic explanation through tutorial, worked problem, tools, references, exercises/quizzes and progression. The architecture must permit large content expansion without hard-coding content into UI.

## Engineering requirement
- Monorepo with apps/packages.
- Next.js frontend.
- NestJS modular monolith backend initially.
- PostgreSQL + Prisma.
- Redis for cache/rate limiting/session support.
- Shared types/UI/database packages.
- Docker/NGINX/CI.
- Security by design.
- Admin/CMS workflow.
- Automated tests and observable health.

## Reconciliation decisions
1. `web-client` is the canonical public web app name; `web-app` from the supplied prompt is treated as legacy naming.
2. Modular monolith is the initial backend; microservices/Kubernetes are scale-up options.
3. Shop/subscription remain modular and can be disabled until business requirements are finalized.
4. Search starts with PostgreSQL; dedicated search is introduced only when justified.
5. No absolute “100% secure/zero error” claim; release criteria are measurable.


---
## V3 Addendum
V3 is the authoritative implementation baseline. Earlier V1/V2 statements in this document are retained as historical design context; when they conflict with V3 code/configuration, V3 implementation and `docs/18-FINAL-AUDIT-V3.md` take precedence.
