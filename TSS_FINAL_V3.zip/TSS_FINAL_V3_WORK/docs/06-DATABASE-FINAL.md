# Database Final

Core: User, Role, Session, Category, Tag, Material, MaterialRevision, Tutorial, Problem, Quiz, Question, Answer, Progress, Bookmark, LearningHistory, Tool, Product, Comment, Media, Notification, AuditLog, Setting.

Rules: UUID identifiers, unique slugs, deliberate foreign-key behavior, indexes for filters/search, timestamps, soft delete where history/audit requires it, revision history for published content, hashed passwords/refresh tokens only.

Content JSON must be schema validated before persistence.


---
## V3 Addendum
V3 is the authoritative implementation baseline. Earlier V1/V2 statements in this document are retained as historical design context; when they conflict with V3 code/configuration, V3 implementation and `docs/18-FINAL-AUDIT-V3.md` take precedence.
