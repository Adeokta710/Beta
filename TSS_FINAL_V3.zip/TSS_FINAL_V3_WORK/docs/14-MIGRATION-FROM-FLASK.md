# Flask → TSS Final Migration

Legacy: `tss/templates` → Next.js pages/components.
Legacy: `tss/static` → Tailwind/component assets.
Legacy: `app.py`, utils, data → NestJS modules/services.
Legacy models → Prisma schema/shared types.
SQLite data → PostgreSQL migration/ETL.

Migration principle: preserve business behavior and original navigation before redesigning internals.
