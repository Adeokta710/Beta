# Release Gate

## Before production
- [ ] Install dependencies from a trusted registry.
- [ ] `pnpm db:generate`
- [ ] `pnpm db:migrate`
- [ ] `pnpm db:seed`
- [ ] `pnpm typecheck`
- [ ] `pnpm test`
- [ ] `pnpm build`
- [ ] Docker build all services.
- [ ] Run API + web + admin against PostgreSQL/Redis.
- [ ] Verify auth register/login/refresh/logout.
- [ ] Verify admin authorization and audit log.
- [ ] Verify CRUD for all content domains.
- [ ] Verify bookmark/progress/quiz/search.
- [ ] Verify mobile drawer and responsive layouts.
- [ ] Run accessibility checks.
- [ ] Configure real email/object storage/payment providers if those features are enabled.
- [ ] Configure backups, secrets, monitoring, alerting and rollback.
