# API Final

Base `/api/v1`.

Health: GET `/health`, `/ready`.
Auth: register/login/refresh/logout/logout-all/me.
Learning: list/detail/create/update/publish.
Tutorials/problems: list/detail.
Learning state: progress/bookmarks/history.
Search: q/type/category/page/cursor.
Admin: categories/content/users/media/settings/audit.

All input is validated. Responses use a consistent envelope/error format. Pagination is cursor/limit where useful. Request IDs are propagated. Sensitive fields are never returned.


---
## V3 Addendum
V3 is the authoritative implementation baseline. Earlier V1/V2 statements in this document are retained as historical design context; when they conflict with V3 code/configuration, V3 implementation and `docs/18-FINAL-AUDIT-V3.md` take precedence.
