# Testing & QA

Gates: lint, typecheck, unit tests, integration tests, API contract tests, frontend component tests, E2E critical paths, accessibility checks, dependency audit, secret scan, container scan.

Critical E2E: register → login → browse category → open material → bookmark → update progress → logout; admin login → edit draft → preview → publish → audit entry.

No “zero error” claim until tests are executed in the target environment.


---
## V3 Addendum
V3 is the authoritative implementation baseline. Earlier V1/V2 statements in this document are retained as historical design context; when they conflict with V3 code/configuration, V3 implementation and `docs/18-FINAL-AUDIT-V3.md` take precedence.
