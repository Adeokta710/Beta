# Security Final

Authentication: Argon2id preferred, short-lived access token, rotating refresh token in HttpOnly/Secure/SameSite cookie, server-side session hash/revocation, logout-all.

Authorization: USER, INSTRUCTOR, ADMIN, SUPERADMIN with resource-level checks.

Protection: TLS, strict CORS, CSP, HSTS, X-Content-Type-Options, Referrer-Policy, Permissions-Policy, CSRF strategy for cookie auth, validation/output encoding, upload validation, SSRF-safe outbound requests.

Rate limit: login, register, reset, search, quiz, comments and other abuse-prone routes.

Operations: secret manager/environment, dependency/SAST/secret/container scans, backups and restore drills, audit logs, monitoring, rollback.


---
## V3 Addendum
V3 is the authoritative implementation baseline. Earlier V1/V2 statements in this document are retained as historical design context; when they conflict with V3 code/configuration, V3 implementation and `docs/18-FINAL-AUDIT-V3.md` take precedence.
