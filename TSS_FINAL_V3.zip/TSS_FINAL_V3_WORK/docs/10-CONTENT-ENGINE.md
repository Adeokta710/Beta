# Content Engine

Content types: Material, Tutorial, Problem Solved, Quiz, Tool, Reference.

Each learning object can link to categories/tags, prerequisites, related content, estimated duration, difficulty, author/reviewer, revision, media and progress.

The final platform must be able to grow from beginner explanations to advanced material without embedding content in source code.


---
## V3 Addendum
V3 is the authoritative implementation baseline. Earlier V1/V2 statements in this document are retained as historical design context; when they conflict with V3 code/configuration, V3 implementation and `docs/18-FINAL-AUDIT-V3.md` take precedence.
