# Roadmap

0 Architecture freeze → 1 monorepo → 2 database → 3 API → 4 UI → 5 auth/security → 6 admin/CMS → 7 learning/search/tools → 8 content seeding → 9 QA → 10 deployment → 11 security review → release.

Kubernetes/microservices only after scale evidence. Shop/subscriptions remain modular until business rules are final.
