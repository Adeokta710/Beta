# UI/UX Final

## Visual language
- Dark blue primary surfaces.
- Sky blue accent for active/interactive states.
- White primary text; black/deep surfaces where appropriate.
- Cards with restrained borders and elevation.
- Consistent 4/8px spacing rhythm.
- Accessible contrast and keyboard focus.
- Plus Jakarta Sans or equivalent modern sans-serif.

## Layout
Desktop: fixed/collapsible sidebar + sticky header + scrollable main + footer. Mobile: top bar + drawer + optional bottom shortcuts.

## Animation
Use short transform/opacity transitions; respect `prefers-reduced-motion`. Avoid animation that blocks reading or causes layout shift.

## States
Every data-driven screen defines loading, skeleton, empty, error, unauthorized and success states.

## Component inventory
Button, IconButton, Input, Search, Select, Tabs, Badge, Card, Breadcrumb, Accordion, Sidebar, Header, Footer, Drawer, Modal, Toast, DataTable, Pagination, ContentCard, ProgressBar, TOC, CodeBlock, Callout, QuizQuestion, AdminEditor, MediaPicker.
