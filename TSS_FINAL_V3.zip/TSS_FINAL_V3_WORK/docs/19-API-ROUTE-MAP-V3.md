# API Route Map V3

Base URL: `/api/v1`

## Public
- GET `/health`
- POST `/auth/register`
- POST `/auth/login`
- POST `/auth/refresh`
- POST `/auth/logout`
- GET `/categories`
- GET `/categories/:id`
- GET `/courses`
- GET `/courses/:id`
- GET `/tutorials`
- GET `/tutorials/:slug`
- GET `/problems`
- GET `/problems/:slug`
- GET `/quiz`
- GET `/quiz/:id`
- GET `/tools`
- GET `/search?q=...`
- GET `/shop/products`

## Authenticated
- GET `/auth/me`
- GET `/bookmarks`
- POST `/bookmarks`
- DELETE `/bookmarks`
- GET `/progress`
- PUT `/progress`
- GET `/learning/overview`
- GET `/notifications`
- PATCH `/notifications/:id/read`
- POST `/quiz/:id/attempt`
- POST `/shop/products/:id/interest`

## Admin
- POST/PATCH/DELETE `/categories`
- POST/PATCH/DELETE `/courses`
- POST `/tutorials`
- POST `/problems`
- POST `/media`
- POST `/shop/products`
- GET `/audit`
- GET `/admin/dashboard`

The implementation can be expanded with dedicated DTOs and CRUD endpoints for each CMS domain without changing the public taxonomy.
