# Original Menu & Taxonomy — Preserved

## Primary navigation
- Home
- Belajar
- Materi
- Tutorial
- Problem Solved
- Tools
- Progress
- Bookmark
- Profile
- Admin
- Shop (modular/optional)

## Learning domains
### Coding & Programming
HTML, CSS, JavaScript, Python, C, C++, Java, Kotlin, PHP, SQL, Dart, Go, Rust.

### Elektronika
Dasar Elektronika, Hukum Dasar, Alat Ukur, Komponen, Audio, Power Supply, Mikrokontroler.

### Hardware & Software
Computer, Smartphone, Networking, Software.

## Electronics component example — Resistor
Resistor is a first-class category/content subject. The content model should support: definition, symbol, unit, types, color code, SMD marking, power rating, tolerance, series/parallel, voltage/current/power relationships, measurement with multimeter, common faults, troubleshooting, examples, exercises and related tutorials/tools.

## Deeper taxonomy
Coding/JavaScript → Fundamental → Variable, Data Type, Function, Array, Object, DOM, Event, API, Async/Await, Module, Advanced.

Elektronika/Komponen → Resistor, Capacitor, Diode, Transistor, MOSFET, IC, Relay, Transformer, Fuse, Switch, Connector, Sensor, Motor, Optocoupler, SCR, TRIAC, IGBT, Varistor.

Elektronika/Mikrokontroler → Arduino, ESP8266, ESP32, STM32, AVR, PIC, Raspberry Pi, GPIO, PWM, ADC, UART, I2C, SPI.

Hardware/Networking → LAN, Ethernet, WiFi, Bluetooth, Router, Modem, Access Point, IP, DNS, Internet.
