# Tools

Initial catalog boundary: Ohm's Law calculator, resistor divider calculator, JSON formatter, electrical unit conversion, plus future electronics/programming utilities.

Tools are versioned and independently testable. Inputs must be validated and calculations must have deterministic tests.
