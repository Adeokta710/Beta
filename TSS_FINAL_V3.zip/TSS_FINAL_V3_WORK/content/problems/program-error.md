# Program Error

## Masalah
Aplikasi gagal pada input atau runtime tertentu

## Gejala
Sistem tidak menghasilkan hasil yang diharapkan.

## Kemungkinan Penyebab
Reproduksi error, baca log/stack trace, isolasi input, uji unit.

## Pemeriksaan
Mulai dari pemeriksaan visual/log, input, koneksi, konfigurasi, lalu komponen terkait.

## Pengukuran
Gunakan alat ukur atau log yang sesuai dan aman.

## Analisis
Bandingkan hasil dengan spesifikasi/dokumentasi.

## Solusi
Perbaiki akar masalah, bukan hanya gejala.

## Pencegahan
Dokumentasikan penyebab, solusi, dan regression check.
