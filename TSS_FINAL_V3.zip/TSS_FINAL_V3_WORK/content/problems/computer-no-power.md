# Komputer Tidak Menyala

## Masalah
Tidak ada respons saat tombol power ditekan

## Gejala
Sistem tidak menghasilkan hasil yang diharapkan.

## Kemungkinan Penyebab
Periksa AC, PSU, kabel, tombol, motherboard dan short.

## Pemeriksaan
Mulai dari pemeriksaan visual/log, input, koneksi, konfigurasi, lalu komponen terkait.

## Pengukuran
Gunakan alat ukur atau log yang sesuai dan aman.

## Analisis
Bandingkan hasil dengan spesifikasi/dokumentasi.

## Solusi
Perbaiki akar masalah, bukan hanya gejala.

## Pencegahan
Dokumentasikan penyebab, solusi, dan regression check.
