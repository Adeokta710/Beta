# Power Amplifier Tidak Mengeluarkan Suara

## Masalah
Tidak ada audio pada output

## Gejala
Sistem tidak menghasilkan hasil yang diharapkan.

## Kemungkinan Penyebab
Periksa supply, input, mute/protection, jalur speaker, dan komponen output.

## Pemeriksaan
Mulai dari pemeriksaan visual/log, input, koneksi, konfigurasi, lalu komponen terkait.

## Pengukuran
Gunakan alat ukur atau log yang sesuai dan aman.

## Analisis
Bandingkan hasil dengan spesifikasi/dokumentasi.

## Solusi
Perbaiki akar masalah, bukan hanya gejala.

## Pencegahan
Dokumentasikan penyebab, solusi, dan regression check.
