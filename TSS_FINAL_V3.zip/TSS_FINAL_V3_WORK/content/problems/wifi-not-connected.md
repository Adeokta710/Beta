# WiFi Tidak Terhubung

## Masalah
Perangkat gagal memperoleh koneksi

## Gejala
Sistem tidak menghasilkan hasil yang diharapkan.

## Kemungkinan Penyebab
Periksa radio, SSID, password, DHCP, gateway, DNS.

## Pemeriksaan
Mulai dari pemeriksaan visual/log, input, koneksi, konfigurasi, lalu komponen terkait.

## Pengukuran
Gunakan alat ukur atau log yang sesuai dan aman.

## Analisis
Bandingkan hasil dengan spesifikasi/dokumentasi.

## Solusi
Perbaiki akar masalah, bukan hanya gejala.

## Pencegahan
Dokumentasikan penyebab, solusi, dan regression check.
