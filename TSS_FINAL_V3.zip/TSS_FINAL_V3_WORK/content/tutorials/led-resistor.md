# Menentukan Resistor LED

## Tujuan
Menentukan resistor pembatas arus

## Alat
Perangkat yang sesuai dan dokumentasi teknis.

## Bahan
Komponen atau data sesuai tutorial.

## Persiapan
Pastikan koneksi benar, sumber daya aman, dan backup konfigurasi jika relevan.

## Langkah
1. Tentukan tegangan sumber
2. Gunakan Vf LED dari datasheet
3. Tentukan arus target
4. Hitung R=(Vs-Vf)/I
5. Pilih resistor dengan rating daya memadai

## Pengujian
Verifikasi hasil terhadap nilai/behavior yang diharapkan.

## Hasil
Catat hasil pengujian dan kondisi abnormal.

## Troubleshooting
Periksa koneksi, konfigurasi, input, dan batas spesifikasi.

## Kesimpulan
Tutorial selesai setelah hasil tervalidasi.
