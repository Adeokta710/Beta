# LED Output ESP32

## Tujuan
Menguji GPIO sebagai output

## Alat
Perangkat yang sesuai dan dokumentasi teknis.

## Bahan
Komponen atau data sesuai tutorial.

## Persiapan
Pastikan koneksi benar, sumber daya aman, dan backup konfigurasi jika relevan.

## Langkah
1. Pilih GPIO yang sesuai board
2. Pasang LED + resistor
3. Program output HIGH/LOW
4. Uji dan amati arus
5. Matikan bila panas/abnormal

## Pengujian
Verifikasi hasil terhadap nilai/behavior yang diharapkan.

## Hasil
Catat hasil pengujian dan kondisi abnormal.

## Troubleshooting
Periksa koneksi, konfigurasi, input, dan batas spesifikasi.

## Kesimpulan
Tutorial selesai setelah hasil tervalidasi.
