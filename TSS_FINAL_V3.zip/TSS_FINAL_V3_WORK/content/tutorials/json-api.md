# Menguji JSON API

## Tujuan
Menguji request dan response API

## Alat
Perangkat yang sesuai dan dokumentasi teknis.

## Bahan
Komponen atau data sesuai tutorial.

## Persiapan
Pastikan koneksi benar, sumber daya aman, dan backup konfigurasi jika relevan.

## Langkah
1. Kirim GET ke endpoint
2. Periksa status HTTP
3. Validasi content-type
4. Periksa struktur JSON
5. Tangani error response

## Pengujian
Verifikasi hasil terhadap nilai/behavior yang diharapkan.

## Hasil
Catat hasil pengujian dan kondisi abnormal.

## Troubleshooting
Periksa koneksi, konfigurasi, input, dan batas spesifikasi.

## Kesimpulan
Tutorial selesai setelah hasil tervalidasi.
