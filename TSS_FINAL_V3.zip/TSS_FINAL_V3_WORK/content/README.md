# TSS Learning Content

This directory is the content source layer for TSS.

## Authoring contract
Every learning article should cover, when applicable:
1. Pengertian
2. Fungsi
3. Jenis
4. Karakteristik/spesifikasi
5. Cara kerja
6. Contoh
7. Perhitungan
8. Pengukuran/pengujian
9. Troubleshooting
10. Praktik
11. Ringkasan
12. Materi terkait

Tutorials use: Tujuan → Alat → Bahan → Persiapan → Langkah → Pengujian → Hasil → Troubleshooting → Kesimpulan.

Problem Solved uses: Masalah → Gejala → Kemungkinan Penyebab → Pemeriksaan → Pengukuran → Analisis → Solusi → Pencegahan.

The catalog preserves the original TSS terminology and taxonomy supplied in the project sources. Starter articles are intentionally concise foundations; publishing a production library requires editorial expansion and original media/datasheet references where relevant.
