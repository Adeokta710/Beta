# Dasar Power Supply

**Domain:** Elektronika  
**Level:** Pemula

## Pengertian
Power supply mengubah atau mengatur energi listrik sesuai kebutuhan rangkaian.

## Konsep / Perhitungan
AC/DC, rectifier, filter, regulator, buck/boost, SMPS, battery, charger, BMS.

## Jenis / Bagian Penting
Linear regulator dan switching regulator.

## Praktik
Praktik hanya pada tegangan rendah yang aman.

## Pengujian
Periksa tegangan, arus, ripple, polaritas, dan proteksi.

## Troubleshooting & Keselamatan
Jangan menguji bagian mains tanpa prosedur keselamatan yang sesuai.

## Ringkasan
Pahami konsep, lakukan praktik terkontrol, validasi hasil, dan dokumentasikan temuan.
