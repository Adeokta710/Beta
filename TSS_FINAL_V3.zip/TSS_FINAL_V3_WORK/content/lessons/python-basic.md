# Dasar Python

**Domain:** Coding & Programming  
**Level:** Pemula

## Pengertian
Python adalah bahasa serbaguna untuk automation, web, data, dan scripting.

## Konsep / Perhitungan
Variable, tipe data, operator, if/else, loop, function.

## Jenis / Bagian Penting
List, tuple, dictionary, set, file, exception, module, package, OOP, API, Flask, database.

## Praktik
Buat program CLI sederhana dengan validasi input.

## Pengujian
Tangani ValueError dan file yang tidak ditemukan.

## Troubleshooting & Keselamatan
Gunakan fungsi dan exception handling sejak awal.

## Ringkasan
Pahami konsep, lakukan praktik terkontrol, validasi hasil, dan dokumentasikan temuan.
