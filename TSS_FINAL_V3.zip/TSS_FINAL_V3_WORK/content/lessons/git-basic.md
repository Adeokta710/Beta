# Dasar Git

**Domain:** Coding & Programming  
**Level:** Pemula

## Pengertian
Git adalah version control terdistribusi.

## Konsep / Perhitungan
init/clone, status, add, commit, branch, merge, pull, push.

## Jenis / Bagian Penting
Branching dan review.

## Praktik
Buat branch fitur dan merge setelah review.

## Pengujian
Periksa diff sebelum commit.

## Troubleshooting & Keselamatan
Jangan menyimpan secret di repository.

## Ringkasan
Pahami konsep, lakukan praktik terkontrol, validasi hasil, dan dokumentasikan temuan.
