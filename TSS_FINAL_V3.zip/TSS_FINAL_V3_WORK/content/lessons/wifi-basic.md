# Dasar WiFi

**Domain:** Hardware & Software  
**Level:** Pemula

## Pengertian
WiFi menghubungkan perangkat melalui jaringan radio lokal.

## Konsep / Perhitungan
Pahami SSID, password, channel, IP, gateway, DNS.

## Jenis / Bagian Penting
Bedakan masalah link/radio, IP, DNS, dan aplikasi.

## Praktik
Cek IP dan gateway pada perangkat.

## Pengujian
Uji konektivitas bertahap dari lokal ke internet.

## Troubleshooting & Keselamatan
Gunakan konfigurasi keamanan jaringan yang sesuai.

## Ringkasan
Pahami konsep, lakukan praktik terkontrol, validasi hasil, dan dokumentasikan temuan.
