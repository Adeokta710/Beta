# Dasar CSS

**Domain:** Coding & Programming  
**Level:** Pemula

## Pengertian
CSS mengatur presentasi dan layout halaman.

## Konsep / Perhitungan
Selector + property + value.

## Jenis / Bagian Penting
Box model, display, position, flexbox, grid, responsive, animation, modern CSS.

## Praktik
Ubah card menjadi responsive grid.

## Pengujian
Uji viewport desktop dan mobile.

## Troubleshooting & Keselamatan
Pisahkan struktur HTML dari presentasi CSS.

## Ringkasan
Pahami konsep, lakukan praktik terkontrol, validasi hasil, dan dokumentasikan temuan.
