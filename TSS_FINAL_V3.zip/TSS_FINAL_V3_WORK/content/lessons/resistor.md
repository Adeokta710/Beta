# Resistor

**Domain:** Elektronika  
**Level:** Pemula

## Pengertian
Resistor membatasi arus dan membentuk pembagian tegangan.

## Konsep / Perhitungan
R = V/I; P = V×I = I²R = V²/R.

## Jenis / Bagian Penting
Resistor biasa, SMD, power resistor, variable resistor, potensiometer, trimpot, NTC, PTC, LDR.

## Praktik
Perhatikan nilai resistansi, toleransi, dan rating daya.

## Pengujian
Lepaskan sumber daya dan idealnya angkat salah satu kaki untuk pengukuran yang akurat.

## Troubleshooting & Keselamatan
Resistor gosong perlu dicari penyebab arus/daya berlebih sebelum diganti.

## Ringkasan
Pahami konsep, lakukan praktik terkontrol, validasi hasil, dan dokumentasikan temuan.
