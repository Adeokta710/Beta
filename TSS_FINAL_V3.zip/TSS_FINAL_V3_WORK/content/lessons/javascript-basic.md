# Dasar JavaScript

**Domain:** Coding & Programming  
**Level:** Pemula

## Pengertian
JavaScript menambahkan perilaku dan logika pada web.

## Konsep / Perhitungan
Variable, data type, operator, conditional, loop, function, array, object.

## Jenis / Bagian Penting
DOM, event, JSON, Fetch API, Promise, async/await, local storage, module.

## Praktik
Buat kalkulator sederhana dan validasi input.

## Pengujian
Uji input kosong, angka invalid, dan error network.

## Troubleshooting & Keselamatan
Validasi input dan tangani error.

## Ringkasan
Pahami konsep, lakukan praktik terkontrol, validasi hasil, dan dokumentasikan temuan.
