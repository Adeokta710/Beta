# Multimeter

**Domain:** Elektronika  
**Level:** Pemula

## Pengertian
Multimeter mengukur tegangan, arus, resistansi dan fungsi lain tergantung model.

## Konsep / Perhitungan
Tegangan diukur paralel; arus diukur seri; resistansi dilakukan tanpa sumber daya aktif.

## Jenis / Bagian Penting
Mulai dari range tertinggi bila tidak yakin.

## Praktik
Ukur baterai DC lalu resistor.

## Pengujian
Hindari salah jack saat pengukuran arus dan salah mode.

## Troubleshooting & Keselamatan
Ikuti rating CAT alat dan prosedur kerja.

## Ringkasan
Pahami konsep, lakukan praktik terkontrol, validasi hasil, dan dokumentasikan temuan.
