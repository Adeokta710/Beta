# Hukum Ohm

**Domain:** Elektronika  
**Level:** Pemula

## Pengertian
Hukum Ohm menghubungkan tegangan (V), arus (I), dan hambatan (R).

## Konsep / Perhitungan
V = I × R; I = V/R; R = V/I.

## Jenis / Bagian Penting
Gunakan dua besaran yang diketahui untuk menghitung besaran ketiga.

## Praktik
Contoh: 12 V pada 1 kΩ menghasilkan 12 mA.

## Pengujian
Ukur tegangan paralel dan arus secara seri; pilih range alat ukur yang aman.

## Troubleshooting & Keselamatan
Ikuti rating alat ukur dan jangan mengukur rangkaian bertegangan dengan mode resistance.

## Ringkasan
Pahami konsep, lakukan praktik terkontrol, validasi hasil, dan dokumentasikan temuan.
