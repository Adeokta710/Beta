# Dasar SQL

**Domain:** Coding & Programming  
**Level:** Pemula

## Pengertian
SQL digunakan untuk membaca dan memanipulasi data relasional.

## Konsep / Perhitungan
SELECT, WHERE, ORDER BY, GROUP BY, JOIN, INSERT, UPDATE, DELETE.

## Jenis / Bagian Penting
Constraint, index, transaction, relation.

## Praktik
Query data kategori dan materi.

## Pengujian
Uji NULL, duplicate, dan foreign key.

## Troubleshooting & Keselamatan
Gunakan parameterized query.

## Ringkasan
Pahami konsep, lakukan praktik terkontrol, validasi hasil, dan dokumentasikan temuan.
