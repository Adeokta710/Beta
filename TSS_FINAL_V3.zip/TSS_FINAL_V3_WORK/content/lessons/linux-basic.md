# Dasar Linux

**Domain:** Hardware & Software  
**Level:** Pemula

## Pengertian
Linux adalah keluarga sistem operasi berbasis kernel Linux.

## Konsep / Perhitungan
Filesystem, shell, permission, process, package manager.

## Jenis / Bagian Penting
Path absolut/relatif, user/group, permission, process.

## Praktik
Buat user, file, directory, dan atur permission pada environment latihan.

## Pengujian
Periksa ownership dan permission.

## Troubleshooting & Keselamatan
Gunakan prinsip least privilege.

## Ringkasan
Pahami konsep, lakukan praktik terkontrol, validasi hasil, dan dokumentasikan temuan.
