# ESP32 GPIO

**Domain:** Mikrokontroler  
**Level:** Pemula

## Pengertian
GPIO ESP32 digunakan sebagai input/output digital dan mendukung fungsi peripheral tertentu.

## Konsep / Perhitungan
Pahami input, output, pull-up/pull-down, dan batas tegangan board.

## Jenis / Bagian Penting
GPIO tidak selalu identik pada semua board.

## Praktik
Uji LED output dan tombol input dengan debounce.

## Pengujian
Uji satu pin per fungsi dan cek dokumentasi board.

## Troubleshooting & Keselamatan
Jangan melebihi batas tegangan/current yang ditentukan board.

## Ringkasan
Pahami konsep, lakukan praktik terkontrol, validasi hasil, dan dokumentasikan temuan.
