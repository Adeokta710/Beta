# Dasar HTML

**Domain:** Coding & Programming  
**Level:** Pemula

## Pengertian
HTML menyusun struktur semantik halaman web.

## Konsep / Perhitungan
Dokumen minimal: doctype, html, head, body.

## Jenis / Bagian Penting
Heading, paragraph, link, image, list, table, form, dan semantic HTML.

## Praktik
Buat halaman profil dengan header, main, section, footer.

## Pengujian
Validasi struktur dan atribut penting sebelum styling.

## Troubleshooting & Keselamatan
Gunakan struktur semantik dan label form yang jelas.

## Ringkasan
Pahami konsep, lakukan praktik terkontrol, validasi hasil, dan dokumentasikan temuan.
