# TSS FINAL V3 — Total Foundation & Learning Platform

Technology Study Surabaya (TSS) — **Ayo Arek-Arek Suroboyo, Belajar Teknologi mulai Saiki**.

V3 is the consolidated implementation foundation derived from the supplied TSS design, the latest `Prompt web.md`, the conversation source, and the previous V1/V2 project packages. The original navigation/taxonomy is preserved while missing foundations are added.

## Stack
- Web: Next.js 14 App Router + React 18 + CSS design system
- API: NestJS 10 + Prisma 5 + PostgreSQL
- Cache/scale foundation: Redis
- Monorepo: pnpm + Turborepo
- Infra: Docker Compose + NGINX + Prometheus + optional Kubernetes
- Admin: separate Next.js admin-panel

## Quick start
1. Copy `.env.example` files.
2. Set a strong `JWT_SECRET` and `SEED_ADMIN_PASSWORD`.
3. Start PostgreSQL/Redis: `docker compose up -d postgres redis`.
4. `pnpm install`
5. `pnpm db:generate`
6. `pnpm db:migrate`
7. `pnpm db:seed`
8. `pnpm dev`

Public web: `http://localhost:3000`  
API: `http://localhost:4000/api/v1`  
Admin: `http://localhost:3001`

Default seed admin is `admin@tss.local`; the password is controlled by `SEED_ADMIN_PASSWORD` and defaults only for development. Change it before deployment.

## Verification
Run `pnpm verify`. The repository includes static source checks and Node foundation tests. Full runtime verification requires dependency installation and a running PostgreSQL/Redis environment; V3 does not falsely mark unavailable runtime checks as passed.

## Content
`content/` contains the learning catalog, taxonomy, lesson starters, tutorials, troubleshooting/problem templates, and quiz seeds. `docs/` defines the content authoring contract so every published learning item can follow a consistent structure.
