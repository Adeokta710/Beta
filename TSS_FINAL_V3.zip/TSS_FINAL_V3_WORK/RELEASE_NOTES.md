# TSS FINAL V3 — Release Notes

## V3 goals
Convert the V2 skeleton into a substantially complete learning-platform foundation without removing the original TSS navigation and learning taxonomy.

## Major changes
- Replaced the previous minimal Prisma schema with a production-oriented PostgreSQL model covering learning, auth, CMS, progress, bookmarks, quiz, shop/order, media, audit and settings.
- Added initial PostgreSQL migration.
- Added session refresh-token rotation and O(n) refresh lookup was removed; refresh tokens carry a session id and are verified against a single session hash.
- Logout now revokes the refresh session.
- Added separate Admin Panel application.
- Added responsive desktop sidebar/mobile drawer.
- Added registration, shop, settings, quiz, tutorial detail and problem detail routes.
- Added complete learning content structure and starter library.
- Fixed Docker build contexts and enabled Next.js standalone output.
- Added admin Docker image and compose service.
- Added source verification and Node foundation tests.
- Removed legacy Tailwind-only placeholder usage and transcript corruption.

## Known runtime prerequisite
Run dependency installation and the database-backed test/build sequence in a target environment with network/package registry access and PostgreSQL/Redis available.
