#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail=0
check(){ local label="$1"; shift; if "$@" >/dev/null 2>&1; then printf 'PASS  %s\n' "$label"; else printf 'FAIL  %s\n' "$label"; fail=1; fi }
check "JSON files parse" python3 - "$ROOT" <<'PY'
import json, pathlib, sys
root=pathlib.Path(sys.argv[1])
for p in root.rglob('*.json'):
    if 'node_modules' in p.parts: continue
    json.loads(p.read_text())
PY
check "No SQLite runtime" bash -c "! grep -RIn 'provider[[:space:]]*=[[:space:]]*\"sqlite\"' '$ROOT' --include='schema.prisma'"
check "No transcript corruption" bash -c "! grep -RInE '## User|## Assistant|Lanjut bagian akhir file' '$ROOT/apps' --include='*.ts' --include='*.tsx'"
check "No legacy web-app refs" bash -c "! grep -RIn 'web-app' '$ROOT/apps' '$ROOT/infra' '$ROOT/packages' --exclude='*.md'"
check "No Tailwind-only placeholders" bash -c "! grep -RInE 'className=\"[^\"]*(text-2xl|p-6|grid-cols-|bg-gray)' '$ROOT/apps' --include='*.tsx'"
check "Migration exists" test -f "$ROOT/apps/api-server/prisma/migrations/0001_initial/migration.sql"
check "Admin panel exists" test -f "$ROOT/apps/admin-panel/app/dashboard/page.tsx"
check "Learning catalog exists" test -f "$ROOT/content/catalog/full-taxonomy.json"
if command -v node >/dev/null 2>&1; then check "Node foundation tests" bash -c "cd '$ROOT/apps/api-server' && node --test test/*.test.mjs"; fi
if command -v tsc >/dev/null 2>&1; then
  check "TypeScript parse API" node - "$ROOT" <<'NODE'
const ts=require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript');const fs=require('fs'),path=require('path');const root=process.argv[2];let bad=0;function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){const f=path.join(d,e.name);if(e.name==='node_modules'||e.name==='dist'||e.name==='.next')continue;if(e.isDirectory())walk(f);else if(/\.(ts|tsx)$/.test(f)){const s=fs.readFileSync(f,'utf8');const r=ts.transpileModule(s,{compilerOptions:{target:ts.ScriptTarget.ES2021,jsx:ts.JsxEmit.ReactJSX,module:ts.ModuleKind.ESNext},reportDiagnostics:true});if((r.diagnostics||[]).length){console.error(f,r.diagnostics);bad=1}}}}walk(path.join(root,'apps'));process.exit(bad)
NODE
fi
if [ "$fail" -ne 0 ]; then exit 1; fi
printf '\nALL STATIC CHECKS PASSED. Runtime dependency/database checks must be run after pnpm install and PostgreSQL is available.\n'
